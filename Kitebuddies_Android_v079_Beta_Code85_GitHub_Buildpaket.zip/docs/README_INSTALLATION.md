# Kitebuddies Nord Forecast Pro – Android v0.79 Beta (Code 85)

## Zweck

Erstellt eine **signierte** Android-APK mit `versionName '0.79 Beta'`, `versionCode 85` und unveränderter Android-Paketkennung `de.kitebuddies.forecast.prc`.

Die WebView öffnet weiterhin `https://api.kitebuddies-nord.de/web-beta/android.php`. Die App enthält **nicht** die komplette Forecast-Datenbank als Offline-Kopie: Sie verwendet die aktuell auf dem Server installierte v0.79 Beta einschließlich Hotfix 07.

Verwendet die bereits auf GitHub vorhandenen, durch SHA-256 geprüften Originaldateien:

- `Kitebuddies_v077_Beta_RC4_Android_Source.zip`
- `Kitebuddies_v0.75_Beta_AdminPush_Android_Source_v77.zip` (Firebase-Konfiguration)
- `.github/workflows/patch_v078_gps84.py` (bereits getestete GPS-/Appsymbol-Erweiterung)

Alle drei Dateien liegen im bestehenden GitHub-Repository. Keine davon muss erneut hochgeladen werden.

## GitHub – Schritt für Schritt

1. Repository öffnen: https://github.com/janluethje1975-bit/kitebuddies-android
2. Auf dem **main**-Branch in den Ordner `.github/workflows/` gehen.
3. **Add file → Upload files** wählen und nur `build-v079-beta.yml` aus diesem Paket hochladen. Prüfen, dass der vollständige Pfad `.github/workflows/build-v079-beta.yml` lautet. Änderung mit **Commit changes** speichern.
4. GitHub → **Actions** öffnen. Links den Workflow **Kitebuddies Nord Forecast Pro v0.79 Beta (Code 85) - signed test APK** auswählen.
5. **Run workflow** → Branch **main** → **Run workflow**.
6. Den neuen Workflowlauf öffnen. Nur wenn der Build grün **Success** meldet, unter **Artifacts** `Kitebuddies-v079-Beta-Code85-signed-TEST` herunterladen.
7. Dieses GitHub-Artefakt ZIP entpacken. Darin liegt die Datei `Kitebuddies_v0.79_Beta_Code85.apk` sowie die SHA-256-Prüfsumme und ein **nicht veröffentlichtes** Update-Manifest.
8. Die APK auf einem Testgerät über die installierte Kitebuddies-App legen. **Nicht deinstallieren und keine App-Daten löschen.**
9. Prüfen: App-Info zeigt 0.79 Beta / Code 85, App-Oberfläche v0.79 mit weltweiter Spotbibliothek, Favoriten, A/B-Anzeige, GPS und Firebase-Push.

## Signierung und Updates

Der Workflow verwendet die vorhandenen GitHub-Secrets `KB_KEYSTORE_B64` und `KB_KEYSTORE_PASSWORD` sowie Alias `kitebuddiespro`. Das finale Zertifikat muss mit SHA-256 `58:D9:51:62:F9:20:1E:46:2D:4B:18:77:20:3A:F1:7E:05:C9:30:99:91:96:83:4E:98:4D:28:BD:57:02:41:63` übereinstimmen. Bei Abweichung bricht der Workflow ab.

Der Workflow **publiziert weder die APK noch das Update-Manifest** auf dem Kitebuddies-Server. Bitte den Inhalt von `V079_UPDATE_MANIFEST_NICHT_AUTOMATISCH_VEROEFFENTLICHEN.json` zunächst nicht in `/kitebuddies-api/updates/pro/kitebuddies-update.json` übernehmen.

## Server-Routing für Code 85 prüfen

Die Android-App ruft weiterhin `/web-beta/android.php` auf. Dessen **Live-Version auf dem Server** muss alle neuen Codes **ab 84 einschließlich Code 85** auf `app-template-v079-beta.php` führen. Dass Code 84 bereits v0.79 lädt, beweist nicht automatisch, dass Code 85 bei einer streng gleichheitsbasierten Versionserkennung ebenfalls richtig geroutet wird. Falls die neue APK nach Installation die alte Oberfläche lädt, zuerst die aktuelle Live-Datei `android.php` sichern und die Versionsweiche prüfen. Eine ältere `android.php` aus dem Chat bitte nicht blind darüberkopieren.

## Voraussetzungen / Grenzen

Der Workflow wurde als YAML sowie auf Versions-, Signatur- und Dateipfade geprüft. Eine echte APK konnte in der Chat-Umgebung **nicht** erstellt werden: Der GitHub-Zugriff erlaubt Lesen, aber keine Schreibaktionen (`403 Resource not accessible by integration`); lokal fehlen Android SDK und Signaturschlüssel. Der GitHub-Actions-Lauf ist daher noch nicht erfolgt.
