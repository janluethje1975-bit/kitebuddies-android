# Kitebuddies Nord Forecast v0.54 – offizielle Firebase-Hülle

Basis: Web-Assets aus der stabilen v0.53. Paket-ID bleibt `de.kitebuddies.forecast.prc`.

## Warum dieses Projekt
Die bisherigen Mini-APKs wurden direkt gepatcht. Für Firebase/FCM wird hier erstmals ein normales Android-Gradle-Projekt mit dem offiziellen `firebase-messaging` SDK verwendet.

## Firebase
- `app/google-services.json` ist enthalten.
- `FirebaseMessagingService` empfängt Tokenänderungen und Daten-Pushs.
- Push wird in der Web-App manuell über **Push verbinden / testen** aktiviert.
- Alarm-ID und Installations-Secret werden ausschließlich lokal gespeichert und zusammen mit dem technischen FCM-Token an die bestehende Alarm-API gesendet.
- Keine Namen, E-Mail-Adressen oder Telefonnummern.

## Build
Das GitHub-Workflow `Build Android` erzeugt zunächst eine **unsigned release APK**. Sie muss anschließend mit dem vorhandenen permanenten Kitebuddies-Pro-Key signiert werden, damit sie über v0.53 installierbar ist.

## Serverseite
Alarm API v1.2.1 unterstützt `action=push-token` bereits. Kein zusätzlicher Serverpatch ist für die Tokenregistrierung nötig.
