package de.kitebuddies.forecast.prc;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class KbFirebaseMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token){super.onNewToken(token);PushRegistrar.sendSavedToken(this,token,null);}
    @Override public void onMessageReceived(RemoteMessage message){
        Map<String,String> d=message.getData(); String title=d.get("title"); String body=d.get("body"); String spot=d.get("spotKey");
        if(title==null||title.isEmpty())title="Kitebuddies Forecast Alarm"; if(body==null||body.isEmpty())body="Forecast-Bedingungen erfüllt.";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE); String ch="kite_alerts";
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(ch,"Kitebuddies Forecast-Alarme",NotificationManager.IMPORTANCE_HIGH));
        Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); if(spot!=null)i.putExtra("kb_spot_key",spot);
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0); PendingIntent pi=PendingIntent.getActivity(this,4101,i,flags);
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi);
        if(Build.VERSION.SDK_INT<33||checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED)nm.notify(4101,b.build());
    }
}
