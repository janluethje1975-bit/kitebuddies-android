# Kitebuddies Nord Forecast Pro v0.56 Beta – Hotfix

Basis: bestätigte, funktionierende v0.54 Beta.

Änderungen:
- VersionCode 56 / VersionName 0.56 Beta
- Android 15+ Statusleisten-Hotfix ohne Umbau der v0.54 Activity-Hülle.
- WebView-Inhalt wird nur um den echten Statusleisten-Inset nach unten versetzt.
- Update-Hinweis beim Start bleibt erhalten.
- „Später“ schließt den Hinweis.
- „Jetzt installieren“ startet den APK-Download direkt; keine Weiterleitung zur Tool-Seite und keine doppelte Update-Anzeige.
- Forecast-, Karten-, Weather-, Firebase-/FCM- und Alarmregel-Logik unverändert gegenüber v0.54.
- Integrierte Anleitung auf v0.56 aktualisiert.

Paket-ID: de.kitebuddies.forecast.prc
Mit permanentem Kitebuddies-SigningKey signieren.


Hotfix build note: minSdk is 24 (Android 7.0+) because current Firebase Messaging requires API 24 or newer.
