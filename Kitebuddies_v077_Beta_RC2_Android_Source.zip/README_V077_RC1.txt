Kitebuddies Nord Forecast Pro – Android v0.77 Beta RC1

Basis: getestete reguläre v0.76 Beta (versionCode 78).
Paket: de.kitebuddies.forecast.prc; versionCode 79; versionName 0.77 Beta RC1.
WebView: https://api.kitebuddies-nord.de/web-beta/android.php

Änderungen:
- Neue zentrale URL, ohne Login-Weiterleitungsschleife.
- Vertrauens-/Migrations-/Alarmspot-Prüfung auf zentralen Android-Pfad angepasst.
- Bei bereits eingerichteten Windalarmen kann das vorhandene FCM-Token
  erneut beim Alarmserver registriert werden (maximal alle 12 Stunden nach
  Erfolg, Fehler frühestens nach 2 Minuten erneut).
- Android-13+-Benachrichtigungsrecht wird bei bereits gekoppelten
  Windalarmen höchstens einmal pro 30 Tagen angefragt.
- Fehlercodes für die Registrierung bleiben nur in privaten App-Prefs;
  keine Tokens oder Passwörter in Logs/Reports.
- Kein Eingriff in Forecast, Tide, Spotimport/-export, Backend oder
  bestehende Nutzerdaten.

NICHT FÜR ALLE TESTER VERÖFFENTLICHEN! Erst signierten
GitHub-Testbuild installieren, altes v0.76-Update unverändert lassen,
Push-Empfang am Gerät und User-Funktionen prüfen.
