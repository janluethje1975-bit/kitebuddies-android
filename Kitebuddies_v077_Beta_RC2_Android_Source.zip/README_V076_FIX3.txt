WebView-Ziel ist v076-beta/android.php. Diese Serverdatei muss mit dem beigefügten Web_iOS UI-Fix-3-Paket installiert sein. Die UI-Fix-3-Logik wird vom Server geladen, nicht aus den APK-Assets.
