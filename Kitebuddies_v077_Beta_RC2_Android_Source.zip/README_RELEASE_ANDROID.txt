REGULÄRER KITEBUDDIES v0.76 BETA RELEASE (versionCode 78)
Basis: erfolgreiche v0.76-STAGE-App, aber Paketkennung nun de.kitebuddies.forecast.prc.
Ziel: /web-beta/v074-beta/android.php (bestehende Android-App aktualisieren, Einstellungen beibehalten).
Native Spot-Dateifreigabe und Dateiauswahl übernommen. Admin-/Firebase-Push-Registrierung wieder aktiviert.
Google-services.json wird beim GitHub-Build aus dem verifizierten v0.75 v77 Vorgängerpaket übernommen.
VOR dem Rollout: Signatur, Installation über v0.75, Push und Profilimport/-export real testen.
Die im Source ZIP enthaltene README_STAGING_ANDROID.txt dokumentiert den HISTORISCHEN Stage-Ausgangspunkt,
ist für dieses reguläre Release nicht mehr maßgeblich.
