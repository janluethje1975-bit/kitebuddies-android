package de.kitebuddies.forecast.prc;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.OutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class PushRegistrar {
    static final String API = "https://api.kitebuddies-nord.de/alarm/index.php";
    static final String PREFS = "kb_push_native";
    static final String DIAG_PREFS = "kb_push_registration_v077rc2";
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    interface Callback { void done(boolean ok, String message); }
    static void saveCredentials(Context c,String id,String secret,String appVersion){
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString("id",id).putString("secret",secret).putString("appVersion",appVersion).apply();
    }
    static void sendSavedToken(Context c,String token,Callback cb){
        SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String id=p.getString("id",""); String secret=p.getString("secret",""); String ver=p.getString("appVersion","0.58 Beta");
        if(id.isEmpty()||secret.isEmpty()){if(cb!=null)cb.done(false,"Alarm-ID noch nicht mit Push verbunden.");return;}
        // When the native APK changes, send the ACTUAL installed version to the server.
        // The previously stored string may still say v0.76 after an in-place upgrade.
        try{ver=c.getPackageManager().getPackageInfo(c.getPackageName(),0).versionName;}
        catch(Exception ignored){}
        sendToken(c,id,secret,ver,token,cb);
    }
    static void sendToken(Context c,String id,String secret,String appVersion,String token,Callback cb){
        EXEC.execute(() -> {
            boolean ok=false; int httpCode=0; String result="nicht ausgeführt";
            String msg="Push-Token konnte nicht gespeichert werden.";
            HttpURLConnection h=null;
            c.getSharedPreferences(DIAG_PREFS,Context.MODE_PRIVATE).edit()
                .putLong("lastAttempt",System.currentTimeMillis()).putString("lastResult","sende").apply();
            try{
                JSONObject j=new JSONObject(); j.put("action","push-token"); j.put("installId",id); j.put("installSecret",secret); j.put("appVersion",appVersion); j.put("pushToken",token);
                h=(HttpURLConnection)new URL(API).openConnection();
                h.setConnectTimeout(15000); h.setReadTimeout(15000); h.setRequestMethod("POST"); h.setDoOutput(true); h.setRequestProperty("Content-Type","application/json; charset=utf-8");
                byte[] b=j.toString().getBytes(StandardCharsets.UTF_8); h.setFixedLengthStreamingMode(b.length);
                try(OutputStream o=h.getOutputStream()){o.write(b);}
                httpCode=h.getResponseCode();
                String response="";
                try(InputStream in=httpCode>=200&&httpCode<300?h.getInputStream():h.getErrorStream()){
                    if(in!=null){
                        ByteArrayOutputStream buf=new ByteArrayOutputStream();
                        byte[] chunk=new byte[2048]; int n;
                        while((n=in.read(chunk))!=-1 && buf.size()<8192){
                            buf.write(chunk,0,Math.min(n,8192-buf.size()));
                        }
                        response=buf.toString("UTF-8");
                    }
                }
                try{
                    JSONObject responseJson=new JSONObject(response);
                    ok=httpCode>=200 && httpCode<300 && responseJson.optBoolean("ok",false);
                    result=ok?"server-ok":httpCode>=200&&httpCode<300?"server-rejected":"http-error";
                }catch(Exception ignored){
                    result="invalid-server-json";
                }
                msg=ok?"Push beim Alarmserver registriert":
                    "Push-Anmeldung fehlgeschlagen (HTTP "+httpCode+", "+result+")";
            }catch(Exception e){
                result="network-"+e.getClass().getSimpleName();
                msg="Push-Registrierung fehlgeschlagen: "+e.getClass().getSimpleName();
            }finally{if(h!=null)h.disconnect();}
            SharedPreferences.Editor ed=c.getSharedPreferences(DIAG_PREFS,Context.MODE_PRIVATE).edit()
                .putString("lastResult",result).putInt("lastHttp",httpCode);
            if(ok)ed.putLong("lastSuccess",System.currentTimeMillis());
            ed.apply();
            if(cb!=null)cb.done(ok,msg);
        });
    }
}
