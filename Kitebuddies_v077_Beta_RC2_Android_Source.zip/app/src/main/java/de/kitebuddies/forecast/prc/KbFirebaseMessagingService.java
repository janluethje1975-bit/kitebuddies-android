package de.kitebuddies.forecast.prc;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.media.AudioAttributes;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.os.Build;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;
import java.util.Map;

public class KbFirebaseMessagingService extends FirebaseMessagingService {
    @Override public void onNewToken(String token){
        super.onNewToken(token);
        getSharedPreferences("kb_push_diagnostics_v077rc2",MODE_PRIVATE).edit()
            .putString("tokenStatus","erneuert").putLong("tokenCheckAt",System.currentTimeMillis()).apply();
        PushRegistrar.sendSavedToken(this,token,null);
    }
    @Override public void onMessageReceived(RemoteMessage message){
        getSharedPreferences("kb_push_diagnostics_v077rc2",MODE_PRIVATE).edit()
            .putLong("lastFcmInboundAt",System.currentTimeMillis()).apply();
        Map<String,String> d=message.getData(); String title=d.get("title"); String body=d.get("body"); String spot=d.get("spotKey");
        RemoteMessage.Notification notification=message.getNotification();
        if((title==null||title.isEmpty())&&notification!=null)title=notification.getTitle();
        if((body==null||body.isEmpty())&&notification!=null)body=notification.getBody();
        if(title==null||title.isEmpty())title="Kitebuddies Forecast Alarm"; if(body==null||body.isEmpty())body="Forecast-Bedingungen erfüllt.";
        NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        String tone=getSharedPreferences("kb_alarm_audio_v059", MODE_PRIVATE).getString("tone","soft");
        if(!"soft".equals(tone)&&!"classic".equals(tone)&&!"strong".equals(tone)&&!"silent".equals(tone))tone="soft";
        String ch="kite_alerts_v059_"+tone;
        int rawId="classic".equals(tone)?R.raw.kb_tone_classic:("strong".equals(tone)?R.raw.kb_tone_strong:R.raw.kb_tone_soft);
        Uri sound=Uri.parse("android.resource://"+getPackageName()+"/"+rawId);
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel channel=new NotificationChannel(ch,"Kitebuddies Forecast - "+tone,NotificationManager.IMPORTANCE_HIGH);
            if("silent".equals(tone))channel.setSound(null,null);
            else channel.setSound(sound,new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
            nm.createNotificationChannel(channel);
        }
        Intent i=new Intent(this,MainActivity.class); i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP); if(spot!=null)i.putExtra("kb_spot_key",spot);
        int flags=PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0); PendingIntent pi=PendingIntent.getActivity(this,4101,i,flags);
        android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(this,ch):new android.app.Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(body).setAutoCancel(true).setContentIntent(pi);
        if(Build.VERSION.SDK_INT<26){if("silent".equals(tone))b.setSound(null);else b.setSound(sound);}
        String result="posted";
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            result="permission-denied";
        }else if(!nm.areNotificationsEnabled()){
            result="notifications-disabled";
        }else if(Build.VERSION.SDK_INT>=26 && nm.getNotificationChannel(ch)!=null &&
             nm.getNotificationChannel(ch).getImportance()==NotificationManager.IMPORTANCE_NONE){
            result="channel-blocked";
        }else{
            try{nm.notify(4101,b.build());}catch(Exception e){result="notify-error-"+e.getClass().getSimpleName();}
        }
        android.content.SharedPreferences.Editor edit=getSharedPreferences("kb_push_diagnostics_v077rc2",MODE_PRIVATE)
            .edit().putString("lastAndroidNotificationResult",result);
        if("posted".equals(result))edit.putLong("lastAndroidNotificationAt",System.currentTimeMillis());
        edit.apply();
    }
}
