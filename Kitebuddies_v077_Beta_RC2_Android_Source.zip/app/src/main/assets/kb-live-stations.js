/* Kitebuddies v0.72 – real observed station values; verified model-skill placeholders.
   No forecast values are relabeled as observations. No interference with forecast algorithms. */
(function(){'use strict';
const ENDPOINT='https://api.kitebuddies-nord.de/kb-stations-v072.php';
const state={active:false,lastKey:'',controller:null,accuracyKey:'',accuracyAt:0};
function get(id){return document.getElementById(id)}
function esc(v){return String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function country(s){return /Dänemark|Danmark|Denmark|Rømø/i.test(s?.region||'')?'DK':'DE'}
function spot(i){return typeof spots!=='undefined'?spots[i]:null}
function index(){return typeof selected!=='undefined'?selected:0}
function endpoint(action,s,extra={}){const u=new URL(ENDPOINT);u.searchParams.set('action',action);u.searchParams.set('latitude',String(s.lat));u.searchParams.set('longitude',String(s.lon));u.searchParams.set('country',country(s));Object.entries(extra).forEach(([k,v])=>u.searchParams.set(k,String(v)));return u.toString()}
async function fetchJSON(url,signal){const response=await fetch(url,{cache:'no-store',signal});if(!response.ok)throw Error('Messstations-Server HTTP '+response.status);const body=await response.json();if(body?.ok===false)throw Error(body.message||body.error||'Keine Messdaten');return body}
function dateLabel(iso){const d=new Date(iso);return Number.isNaN(d.valueOf())?'–':new Intl.DateTimeFormat('de-DE',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Europe/Berlin'}).format(d)}
function num(v,dec=0){return v==null||!Number.isFinite(Number(v))?'–':Number(v).toFixed(dec)}
function getHistory(){return get('kbStationHistory')}
function paintHistory(data,s){const box=getHistory();if(!box)return;
 const station=data.station;const rows=Array.isArray(data.history)?data.history:[];const latest=data.latest||rows[rows.length-1];
 if(!station||!latest){box.innerHTML=`<div class="kb-station-warning">${esc(data.message||'Keine beobachteten Winddaten für einen nahe gelegenen Messpunkt verfügbar. Das ist kein Windwert vom Spot.')}</div>`;return;}
 const stale=data.state!=='live';const age=Math.max(0,Number(data.ageMinutes)||0);
 const nums=rows.filter(r=>Number.isFinite(Number(r.windKn))).slice(-70);
 const min=nums.length?Math.min(...nums.map(r=>Number(r.windKn))):0;
 const max=nums.length?Math.max(1,...nums.map(r=>Number(r.gustKn??r.windKn))):1;
 const vw=520,vh=134,pad=12,span=Math.max(1,max-min);const pts=nums.map((r,i)=>`${pad+(i/Math.max(1,nums.length-1))*(vw-pad*2)},${vh-pad-(Number(r.windKn)-min)/span*(vh-pad*2)}`).join(' ');
 const gustPoints=nums.map((r,i)=>r.gustKn==null?null:`${pad+(i/Math.max(1,nums.length-1))*(vw-pad*2)},${vh-pad-(Number(r.gustKn)-min)/span*(vh-pad*2)}`).filter(Boolean).join(' ');
 const stationDistance=Number(station.distanceKm);
 box.innerHTML=`<div class="kb-station-status ${stale?'kb-station-stale':'kb-station-current'}">${stale?'⚠ Messwert veraltet':'● Beobachtung vorhanden'} · ${esc(data.provider||station.provider)} · ${esc(station.name)} · ${Number.isFinite(stationDistance)?num(stationDistance,1)+' km entfernt':'Entfernung unbekannt'}</div>
 <div class="kb-station-metrics"><div><b>${num(latest.windKn,1)}</b><small>Grundwind · kn</small></div><div><b>${num(latest.gustKn,1)}</b><small>Böen · kn</small></div><div><b>${num(latest.directionDeg)}°</b><small>Wind aus Richtung</small></div></div>
 <div class="kb-station-foot">Messzeit ${dateLabel(latest.time)} · ${age} Minuten alt · Station ${esc(station.id)} · Wind am Messort, nicht am Kite-Spot</div>
 ${nums.length>1?`<div class="kb-station-plot"><svg viewBox="0 0 ${vw} ${vh}" role="img" aria-label="Gemessener Grundwindverlauf der vergangenen Stunden"><polyline fill="none" stroke="#36dbe5" stroke-width="3.1" stroke-linecap="round" stroke-linejoin="round" points="${pts}"></polyline>${gustPoints?`<polyline fill="none" stroke="#ff8ea1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" points="${gustPoints}"></polyline>`:''}</svg><div class="kb-station-legend">Türkis = gemessener Grundwind · Rosa = gemessene Böen (sofern vorhanden) · ${esc(dateLabel(nums[0].time))} bis ${esc(dateLabel(nums[nums.length-1].time))}</div></div>`:''}
 <details class="kb-station-detail"><summary>Messwerte der vergangenen Stunden (${rows.length})</summary><div class="kb-station-table-wrap"><table><thead><tr><th>Gemessen</th><th>Wind</th><th>Böen</th><th>Richtung</th></tr></thead><tbody>${rows.slice(-32).reverse().map(r=>`<tr><td>${esc(dateLabel(r.time))}</td><td>${num(r.windKn,1)} kn</td><td>${num(r.gustKn,1)} kn</td><td>${num(r.directionDeg)}°</td></tr>`).join('')}</tbody></table></div></details>
 <div class="kb-station-note">Messwerte: ${esc(station.provider==='DWD'?'DWD über Bright Sky':station.provider==='DMI'?'DMI Open Data':station.provider)}. Die Messstation kann von den Verhältnissen am Strand abweichen. Es werden nur Beobachtungen, keine modellierten Forecasts als „Live“ angezeigt.</div>`;
}
async function openSpot(i=index()){
 const s=spot(i);if(!s)return;const panel=get('kbStationPanel'),box=getHistory();if(!panel||!box)return;
 panel.hidden=false;state.active=true;const key=`${s.lat}|${s.lon}`;state.lastKey=key;
 get('kbStationSpot').textContent=s.name;box.innerHTML='<div class="kb-station-loading">📡 Messstationsdaten werden beim Server angefragt …</div>';
 panel.scrollIntoView?.({behavior:'smooth',block:'start'});
 if(state.controller)state.controller.abort();state.controller=new AbortController();
 try {const d=await fetchJSON(endpoint('history',s,{hours:24}),state.controller.signal);if(key!==state.lastKey||!state.active)return;paintHistory(d,s);}
 catch(e){if(e?.name==='AbortError')return;box.innerHTML=`<div class="kb-station-warning">Messstation derzeit nicht verfügbar: ${esc(e.message)}. Der Forecast bleibt unabhängig davon nutzbar.</div>`;}
}
function close(){state.active=false;state.lastKey='';if(state.controller)state.controller.abort();const p=get('kbStationPanel');if(p)p.hidden=true}
async function loadAccuracy(force=false){
 const s=spot(index()),body=get('kbModelAccuracyBody'),info=get('kbModelAccuracyInfo');if(!s||!body)return;
 const key=`${s.lat}|${s.lon}`;if(!force&&key===state.accuracyKey&&Date.now()-state.accuracyAt<60000)return;
 state.accuracyKey=key;state.accuracyAt=Date.now();body.innerHTML='<tr><td colspan="4">Verifizierte Modellhistorie wird geladen …</td></tr>';
 try{const d=await fetchJSON(endpoint('accuracy',s));if(key!==state.accuracyKey)return;
 const models=Array.isArray(d.models)?d.models:[];
 body.innerHTML=models.map(m=>`<tr><td>${esc(m.name)}</td><td>${m.meanAbsErrorKn==null?'–':num(m.meanAbsErrorKn,1)+' kn'}</td><td>${m.hitRatePercent==null?'–':num(m.hitRatePercent)+' %'}</td><td>${num(m.samples)}</td></tr>`).join('')||'<tr><td colspan="4">Noch keine verifizierten Modell-Messwert-Paare.</td></tr>';
 if(info)info.textContent=`${s.name}: ${d.note||'Erfassung läuft.'} ${d.definition||''} Letzte Sammlung: ${d.lastCaptureAt?dateLabel(d.lastCaptureAt):'noch keine'}.`;
 }catch(e){body.innerHTML='<tr><td colspan="4">Lernserver noch nicht erreichbar · keine verifizierten Werte</td></tr>';if(info)info.textContent='Bitte zuerst kb-stations-v072.php auf den Kitebuddies-Server hochladen. Keine modellierte Prognose wird als gemessener Treffer gezählt.';}
}
function init(){
 get('kbMenuLiveStationsBtn')?.addEventListener('click',()=>{if(typeof showView==='function')showView('spots');setTimeout(()=>openSpot(),120)});
 get('kbStationCloseBtn')?.addEventListener('click',close);
 get('kbStationRefreshBtn')?.addEventListener('click',()=>openSpot());
 get('kbAccuracyRefreshBtn')?.addEventListener('click',()=>loadAccuracy(true));
 document.querySelectorAll('[data-view="models"]').forEach(b=>b.addEventListener('click',()=>setTimeout(()=>loadAccuracy(true),60)));
 get('spotList')?.addEventListener('click',e=>{const b=e.target.closest?.('[data-kb-station-index]');if(!b)return;e.preventDefault();e.stopPropagation();const i=Number(b.dataset.kbStationIndex);if(Number.isInteger(i)&&spot(i))openSpot(i)});
}
window.KBLiveStations={init,openSpot,close,loadAccuracy,endpoint};
})();
