/* Kitebuddies Nord Forecast Pro v0.18 Beta
   Central Weather/Marine API client. The UI consumes normalized data only.
   Wind overlay is intentionally independent and unchanged. */
(function(){
'use strict';
const BASE='/web-beta/weather-proxy.php';
const TOKEN='';
const REGIONAL_MODELS_URL='/web-beta/weather-proxy.php';
const THERMAL_MODELS_URL="/web-beta/weather-proxy.php";
const MODEL_HOURLY=['wind_speed_10m','wind_direction_10m','wind_gusts_10m','precipitation','temperature_2m','cloud_cover'];
const FULL_HOURLY=['wind_speed_10m','wind_direction_10m','wind_gusts_10m','temperature_2m','apparent_temperature','relative_humidity_2m','dew_point_2m','precipitation_probability','precipitation','rain','showers','snowfall','weather_code','cloud_cover','cloud_cover_low','cloud_cover_mid','cloud_cover_high','pressure_msl','visibility'];
const DAILY=['temperature_2m_min','temperature_2m_max','sunrise','sunset','daylight_duration','precipitation_sum','wind_speed_10m_max','wind_gusts_10m_max'];
const MARINE_HOURLY=['wave_height','wave_direction','wave_period','sea_surface_temperature','sea_level_height_msl','ocean_current_velocity','ocean_current_direction'];
function finite(v){if(v===null||v===undefined||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null}
function csv(v){return Array.isArray(v)?v.join(','):String(v||'')}
function build(action,opts={}){
  const p=new URLSearchParams({action,latitude:String(opts.latitude),longitude:String(opts.longitude),forecast_days:String(opts.days||7),timezone:opts.timezone||'Europe/Berlin'});
  if(opts.model)p.set('model',opts.model);
  if(opts.hourly?.length)p.set('hourly',csv(opts.hourly));
  if(opts.daily?.length)p.set('daily',csv(opts.daily));
  if(opts.cell)p.set('cell_selection',opts.cell);
  const endpoint=(action==='catalog'||(action==='model'&&['ukmo','gem'].includes(String(opts.model||''))))?REGIONAL_MODELS_URL:BASE;
  return endpoint+'?'+p.toString();
}

// v0.70 Pro: thermic/local-wind indicators are fetched only when explicitly enabled.
function thermalUrl(latitude,longitude,opts={}) {
 const p=new URLSearchParams({action:'thermics',latitude:String(latitude),longitude:String(longitude),forecast_days:String(opts.days||7),timezone:opts.timezone||'UTC'});
 if(TOKEN)p.set('token',TOKEN);
 return THERMAL_MODELS_URL+'?'+p.toString();
}

function catalogUrl(){const p=new URLSearchParams({action:'catalog'});return REGIONAL_MODELS_URL+'?'+p.toString()}
let kbExtendedModelPromise=null;
async function extendedModels(){if(kbExtendedModelPromise)return kbExtendedModelPromise;kbExtendedModelPromise=(async()=>{try{const r=await fetch(catalogUrl(),{cache:'no-store'});if(!r.ok)return [];const j=await r.json();return j?.ok&&Array.isArray(j.models)?j.models.filter(k=>['ukmo','gem'].includes(k)):[]}catch(e){return []}})();return kbExtendedModelPromise}
function modelUrl(model,latitude,longitude,opts={}){return build('model',{model,latitude,longitude,hourly:opts.hourly||MODEL_HOURLY,daily:opts.daily||[],days:opts.days||7,timezone:opts.timezone||'Europe/Berlin',cell:opts.cell||'nearest'})}
function fullWeatherUrl(latitude,longitude,opts={}){return build('model',{model:opts.model||'dwd',latitude,longitude,hourly:FULL_HOURLY,daily:DAILY,days:opts.days||7,timezone:opts.timezone||'Europe/Berlin',cell:opts.cell||'nearest'})}
function marineUrl(latitude,longitude,opts={}){return build('marine',{latitude,longitude,hourly:MARINE_HOURLY,days:opts.days||7,timezone:opts.timezone||'Europe/Berlin',cell:opts.cell||'sea'})}
function one(raw){return Array.isArray(raw)?raw[0]:raw}
function arr(h,k){return Array.isArray(h?.[k])?h[k]:[]}
function normalizeWeather(raw){
  const d=one(raw)||{},h=d.hourly||{},times=arr(h,'time');
  const hourly=times.map((time,i)=>({
    time,
    windSpeed:finite(h.wind_speed_10m?.[i]),windDirection:finite(h.wind_direction_10m?.[i]),windGust:finite(h.wind_gusts_10m?.[i]),
    temperature:finite(h.temperature_2m?.[i]),apparentTemperature:finite(h.apparent_temperature?.[i]),humidity:finite(h.relative_humidity_2m?.[i]),dewPoint:finite(h.dew_point_2m?.[i]),
    precipitationProbability:finite(h.precipitation_probability?.[i]),precipitation:finite(h.precipitation?.[i]),rain:finite(h.rain?.[i]),showers:finite(h.showers?.[i]),snowfall:finite(h.snowfall?.[i]),weatherCode:finite(h.weather_code?.[i]),
    cloudCover:finite(h.cloud_cover?.[i]),cloudCoverLow:finite(h.cloud_cover_low?.[i]),cloudCoverMid:finite(h.cloud_cover_mid?.[i]),cloudCoverHigh:finite(h.cloud_cover_high?.[i]),
    pressure:finite(h.pressure_msl?.[i]),visibilityMeters:finite(h.visibility?.[i]),visibilityKm:finite(h.visibility?.[i])!=null?finite(h.visibility?.[i])/1000:null
  }));
  const dy=d.daily||{},dates=arr(dy,'time');
  const daily=dates.map((time,i)=>({time,temperatureMin:finite(dy.temperature_2m_min?.[i]),temperatureMax:finite(dy.temperature_2m_max?.[i]),sunrise:dy.sunrise?.[i]||null,sunset:dy.sunset?.[i]||null,daylightDuration:finite(dy.daylight_duration?.[i]),precipitationSum:finite(dy.precipitation_sum?.[i]),windMax:finite(dy.wind_speed_10m_max?.[i]),gustMax:finite(dy.wind_gusts_10m_max?.[i])}));
  return{hourly,daily,raw:d};
}
function normalizeMarine(raw){
  const d=one(raw)||{},h=d.hourly||{},times=arr(h,'time');
  const hourly=times.map((time,i)=>({time,waveHeight:finite(h.wave_height?.[i]),waveDirection:finite(h.wave_direction?.[i]),wavePeriod:finite(h.wave_period?.[i]),seaTemperature:finite(h.sea_surface_temperature?.[i]),seaLevel:finite(h.sea_level_height_msl?.[i]),currentVelocity:finite(h.ocean_current_velocity?.[i]),currentDirection:finite(h.ocean_current_direction?.[i])}));
  return{hourly,raw:d};
}
function parseTime(v){if(v instanceof Date)return v;const s=String(v||'');if(!s)return new Date(NaN);if(/[zZ]$|[+\-]\d{2}:?\d{2}$/.test(s))return new Date(s);if(/^\d{4}-\d{2}-\d{2}$/.test(s))return new Date(s+'T00:00:00Z');return new Date(s+'Z')}
function nearest(list,time,maxMs=90*60*1000){if(!Array.isArray(list)||!list.length)return null;const target=parseTime(time).getTime();let best=null,dist=Infinity;for(const row of list){const d=Math.abs(parseTime(row.time).getTime()-target);if(d<dist){dist=d;best=row}}return dist<=maxMs?best:null}
function dailyForTime(list,time){if(!Array.isArray(list)||!list.length)return null;const key=String(time||'').slice(0,10);return list.find(x=>String(x.time||'').slice(0,10)===key)||null}
function weatherInfo(code,isDay=true){
  const c=Number(code);
  if(c===0)return{label:'klar',icon:isDay?'☀':'☾'};
  if(c===1)return{label:'leicht bewölkt',icon:isDay?'🌤':'☁'};
  if(c===2)return{label:'bewölkt',icon:'⛅'};
  if(c===3)return{label:'bedeckt',icon:'☁'};
  if(c===45||c===48)return{label:'Nebel',icon:'🌫'};
  if([51,53,55,56,57].includes(c))return{label:'Nieselregen',icon:'🌦'};
  if([61,63,65,66,67].includes(c))return{label:'Regen',icon:'🌧'};
  if([71,73,75,77].includes(c))return{label:'Schnee',icon:'🌨'};
  if([80,81,82].includes(c))return{label:'Schauer',icon:'🌦'};
  if([85,86].includes(c))return{label:'Schneeschauer',icon:'🌨'};
  if([95,96,99].includes(c))return{label:'Gewitter',icon:'⛈'};
  return{label:'Wetterlage',icon:isDay?'⛅':'☁'};
}
window.KBWeatherAPI={BASE,TOKEN,REGIONAL_MODELS_URL,THERMAL_MODELS_URL,thermalUrl,catalogUrl,extendedModels,MODEL_HOURLY,FULL_HOURLY,DAILY,MARINE_HOURLY,modelUrl,fullWeatherUrl,marineUrl,normalizeWeather,normalizeMarine,nearest,dailyForTime,parseTime,weatherInfo,finite};
})();
