/* Kitebuddies v0.74: one mathematical model mixer for spot and map-grid forecasts.
   Historical-learning weights stay DISABLED until independently validated. */
(function(root){
 'use strict';
 function finite(v){if(v===null||v===undefined||v==='')return null;const n=Number(v);return Number.isFinite(n)?n:null}
 function combine(entries){
  const good=(entries||[]).filter(x=>finite(x.wind)!==null&&finite(x.dir)!==null&&finite(x.weight)>0);
  if(!good.length)return null;
  let wx=0,weightSum=0,gustSum=0,gustWeights=0,vx=0,vy=0;
  for(const x of good){const w=Number(x.weight),v=Number(x.wind),a=Number(x.dir)*Math.PI/180;
   wx+=v*w;weightSum+=w;vx+=Math.cos(a)*w;vy+=Math.sin(a)*w;
   const g=finite(x.gust);if(g!==null){gustSum+=g*w;gustWeights+=w}
  }
  const wind=wx/weightSum,dir=((Math.atan2(vy,vx)*180/Math.PI)%360+360)%360;
  return {wind,dir,gust:gustWeights?gustSum/gustWeights:null,modelCount:good.length,
   modelKeys:good.map(x=>x.key||null).filter(Boolean),weightSum};
 }
 function weight(key,lat,lon,time,now=Date.now()){
  const region=root.KBRegionalModels?.region?.(lat,lon)||'global';
  const t=new Date(time).getTime(),lead=Number.isFinite(t)?Math.max(0,(t-now)/3600000):0;
  return Number(root.KBRegionalModels?.weight?.(key,region,lead))||0;
 }
 root.KBUnifiedForecast=Object.freeze({VERSION:'0.74',combine,weight,LEARNING_WEIGHTS_ACTIVE:false});
})(window);
