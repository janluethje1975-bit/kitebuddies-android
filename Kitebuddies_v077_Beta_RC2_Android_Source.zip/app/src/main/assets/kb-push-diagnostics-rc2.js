/* Kitebuddies v0.77 RC2 – native Android-only, non-sensitive push diagnostics.
 * Injected only by MainActivity when the trusted /web-beta/android.php page loads.
 * This script does not modify Web/iOS, alarm rules or server records. */
(function(){
  'use strict';
  if (!window.AndroidPush || typeof window.AndroidPush.diagnostics !== 'function') return;
  var area = document.getElementById('alarmPushTechDetails');
  if (!area || document.getElementById('kbRC2NativePushDiagnostics')) return;

  var panel = document.createElement('div');
  panel.id='kbRC2NativePushDiagnostics';
  panel.style.cssText='margin:12px;padding:13px;border:1px solid #348493;border-radius:12px;background:#07222d;color:#d9f7fb;font-size:12px;line-height:1.55';
  var title=document.createElement('strong');
  title.textContent='Android v0.77 Beta RC2 – Push-Diagnose';
  title.style.cssText='display:block;color:#47dbea;font-size:14px;margin-bottom:4px';
  panel.appendChild(title);
  var desc=document.createElement('div');
  desc.textContent='Native Android-Version und Weboberfläche v0.76 werden getrennt angezeigt. Keine FCM-Tokens oder Zugangsdaten werden ausgegeben.';
  desc.style.cssText='font-size:11px;color:#9cbbca;margin-bottom:10px';
  panel.appendChild(desc);
  var row=document.createElement('div');
  row.style.cssText='display:flex;flex-wrap:wrap;gap:7px;margin-bottom:10px';
  function button(label,fn){
    var b=document.createElement('button'); b.type='button';b.textContent=label;
    b.className='secondary';b.style.cssText='font-size:12px;padding:8px 10px';
    b.addEventListener('click',fn);row.appendChild(b);return b;
  }
  var out=document.createElement('pre');
  out.id='kbRC2NativePushResults';
  out.style.cssText='white-space:pre-wrap;overflow-wrap:anywhere;font:12px/1.6 system-ui,sans-serif;color:#d6eaf0;margin:0';
  var lastServer='Noch nicht geprüft';
  function when(ms){if(!ms)return '–';try{return new Date(ms).toLocaleString('de-DE')}catch(e){return '–'}}
  function getData(){
    var webId='';
    try {if (typeof getAlarmIdentity === 'function') webId=String(getAlarmIdentity().id||'');}catch(e){}
    try{return JSON.parse(window.AndroidPush.diagnostics(webId));}
    catch(e){return {error:'Android-Diagnose nicht verfügbar'};}
  }
  function format(d){
    if(d.error)return d.error;
    return [
      'Android-App: '+d.nativeVersion+' (Code '+d.nativeCode+')',
      'Geladene Weboberfläche: '+d.webVersion,
      'Android-Benachrichtigungsrecht: '+d.permission,
      'Systembenachrichtigungen aktiv: '+(d.notificationsEnabled?'ja':'NEIN'),
      'FCM-Standardkanal: '+d.defaultFcmChannel,
      'FCM-Token abrufbar: '+d.firebaseTokenCheck+' · '+when(d.firebaseTokenCheckAt),
      'Native Alarmkopplung gespeichert: '+(d.nativePaired?'ja':'NEIN'),
      'Native / Web Alarm-ID stimmen überein: '+d.sameAlarmIdentity,
      'Letzte Windalarm-Registrierung: '+d.lastWindRegistration,
      'Antwort Alarmserver: '+d.lastWindServerReply+(d.lastWindHttp?' (HTTP '+d.lastWindHttp+')':''),
      'Registrierungsversuch: '+when(d.lastWindRegistrationAt),
      'Letzte erfolgreiche Kopplung: '+when(d.lastWindSuccessAt),
      'Letzter nativer FCM-Empfang: '+when(d.lastFcmInboundAt),
      'Letzte Android-Benachrichtigung: '+when(d.lastAndroidNotificationAt),
      'Android-Empfangsstatus: '+d.lastAndroidNotificationResult,
      'Admin-Push-Registrierung (separat): '+d.adminRegistration+' · '+when(d.adminRegistrationAt),
      'Alarmserver-Status: '+lastServer,
      '\nHinweis: „Push bereit“ bestätigt nur die Registrierung, nicht die Zustellung.'
    ].join('\n');
  }
  function render(){out.textContent=format(getData());}
  window.KBRC2DiagnosticsUpdated=render;
  button('FCM & Status prüfen',function(){
    try{window.AndroidPush.refreshDiagnostics();}catch(e){}
    lastServer='Wird abgefragt …';render();
    if(typeof alarmApi!=='function'){lastServer='Serverfunktion nicht verfügbar';render();return;}
    Promise.resolve(alarmApi('status')).then(function(d){
      lastServer='Web-Alarm-ID '+(d&&d.pushReady?'hat Push-Token':'hat KEINEN Push-Token');render();
    }).catch(function(e){lastServer='Fehler: '+String(e&&e.message||e).slice(0,100);render();});
  });
  button('Android neu verbinden',function(){
    var d=getData();
    if(d.sameAlarmIdentity==='NEIN'||!d.nativePaired){
      lastServer='Abweichende/fehlende Kopplung: nutze die vorhandene Schaltfläche „Push verbinden / testen“. ';render();
      if(typeof connectOfficialPush==='function')connectOfficialPush();
    }else{
      lastServer='Gespeichertes Gerät wird erneut registriert …';render();
      try{window.AndroidPush.reconnectSaved();}catch(e){lastServer='Native Verbindung konnte nicht gestartet werden.';render();}
    }
  });
  button('Diagnose kopieren',function(){
    var data=out.textContent;
    if(navigator.clipboard&&navigator.clipboard.writeText){
      navigator.clipboard.writeText(data).catch(function(){lastServer='Kopieren nicht möglich; Screenshot verwenden';render();});
    }else{lastServer='Zwischenablage nicht verfügbar; Screenshot verwenden';render();}
  });
  panel.appendChild(row);panel.appendChild(out);area.appendChild(panel);
  var brand=document.querySelector('.brand-title span');
  if(brand && !document.getElementById('kbRC2NativeVersionLabel')){
    var label=document.createElement('small');
    label.id='kbRC2NativeVersionLabel';
    label.style.cssText='display:block;font-size:10px;color:#78f3d7;line-height:1.3;margin-top:2px';
    label.textContent='Android-App 0.77 RC2 · Weboberfläche 0.76';
    brand.parentNode.appendChild(label);
  }
  render();
})();
