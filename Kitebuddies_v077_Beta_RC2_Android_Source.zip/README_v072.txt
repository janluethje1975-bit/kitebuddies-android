Kitebuddies Nord Forecast Pro v0.72 Beta
- Android builds on v0.71 successfully built in GitHub.
- Live measured stations panel DWD/Bright Sky and DMI, from kb-stations-v072.php on own Kitebuddies server.
- Historical accuracy requires server collection. Empty metrics are not bugs before sufficient matched measurements exist.
- Forecast, KiteScore, Confidence, Wind Overlay, Shore, push, Firebase and license unchanged.
- Source bundle must be signed using existing permanent signing key.
