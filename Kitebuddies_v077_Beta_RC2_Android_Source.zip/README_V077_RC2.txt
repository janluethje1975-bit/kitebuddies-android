Kitebuddies Android v0.77 Beta RC2 / versionCode 80 / INTERNAL TEST ONLY

- Stabile Android-Einstiegsadresse /web-beta/android.php, Web/iOS unverändert.
- Native Versionsanzeige und datensparsame Push-Diagnose im Tools-Alarm-Bereich.
- Die Push-Registrierung prüft HTTP UND JSON {ok:true}.
- Manuelle Neuregistrierung gespeicherter Alarmkopplungen (nur auf Benutzerklick).
- Prüft gespeicherte native Alarm-ID gegen die aktuelle Weboberflächen-Alarm-ID, ohne Secrets auszugeben.
- Prüft Firebase-Token-Verfügbarkeit, Android-Benachrichtigungsrecht, System-/FCM-Kanal, letzten Empfang.
- Keine automatische Alarm-Testsendung, keine Änderung an Cron oder täglichen Sperrmarken.
- Forecast, Tide, Benutzerverwaltung, Web/iOS unverändert.
- Firebase Konfiguration nur aus verifiziertem Bestandsarchiv während des Builds.
- Unter keinen Umständen die JSON Update-Meldung produktiv hochladen.
