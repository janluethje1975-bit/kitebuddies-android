Kitebuddies Nord Forecast Pro v0.73 Beta
Basis: v0.72. Küstenlinie über Info-Fähnchen; echter Spotkarten-Filter „Mit Station“; direkte Live-Messstationen im Hamburger-Menü. Stationsfilter basiert auf hinterlegten Stationskennzeichnungen, nicht auf einer zugesicherten Live-Verfügbarkeit. Bestehende Prognose- und Messstations-APIs unverändert.
