Kitebuddies v0.76 Beta SPOT TEST – Android test package only
ApplicationId: de.kitebuddies.forecast.prc.stage (parallel installiert, keine Überschreibung)
VersionCode 78. WebView: /web-beta/v076-beta/android.php
Android Dateiauswahl und Teilen von Spotdateien sind eingebaut.
Kein Firebase-/Admin-Push im Testpaket: Windalarme bitte nur in regulärer v0.75 prüfen.
Die reguläre Android-App, ihre Signatur, Update-JSON und Produktionsserver bleiben unberührt.
