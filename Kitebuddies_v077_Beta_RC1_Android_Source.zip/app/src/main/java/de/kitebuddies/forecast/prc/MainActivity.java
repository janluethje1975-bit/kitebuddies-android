package de.kitebuddies.forecast.prc;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.WindowInsets;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.webkit.ValueCallback;
import androidx.core.content.FileProvider;
import java.io.File;
import java.io.FileOutputStream;
import android.webkit.CookieManager;
import android.webkit.WebResourceError;
import android.content.SharedPreferences;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.io.OutputStream;
import java.net.URL;
import java.net.HttpURLConnection;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATIONS=5201;
    private static final int REQ_ADMIN_NOTIFICATIONS=5202;
    private static final int REQ_RECONNECT_NOTIFICATIONS=5203;
    private static final String ANDROID_HOME="https://api.kitebuddies-nord.de/web-beta/android.php";
    private static final String LEGACY_HOME="file:///android_asset/index.html";
    private static final String MIGRATION_PREFS="kb_security_migration_v073";
    private volatile boolean migrationOpen=false;
    private WebView webView;
    private ValueCallback<Uri[]> spotFilePicker;
    private static final int REQ_SPOT_IMPORT=7610;
    private String pendingId="",pendingSecret="",pendingVersion="";
    private String pendingSpotKey="";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,20,28));
        webView=new WebView(this);
        webView.setBackgroundColor(Color.rgb(8,20,28));
        FrameLayout.LayoutParams webLp=new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(webView,webLp);
        // Keep the system navigation area separate from the WebView on Android 15+.
        // Edge-to-edge enforcement places the Activity behind the Android buttons;
        // the WebView therefore needs BOTH top and bottom layout insets.
        // The separate black background is behind system buttons, never over the app.
        View navigationBarBackground=new View(this);
        navigationBarBackground.setBackgroundColor(Color.BLACK);
        navigationBarBackground.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,0,Gravity.BOTTOM);
        root.addView(navigationBarBackground,navLp);
        if(Build.VERSION.SDK_INT>=35){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int top=insets.getInsets(WindowInsets.Type.statusBars()).top;
                int bottom=insets.getInsets(WindowInsets.Type.navigationBars()).bottom;
                FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)webView.getLayoutParams();
                if(lp.topMargin!=top||lp.bottomMargin!=bottom){
                    lp.topMargin=top;
                    lp.bottomMargin=bottom;
                    webView.setLayoutParams(lp);
                }
                FrameLayout.LayoutParams barLp=(FrameLayout.LayoutParams)navigationBarBackground.getLayoutParams();
                if(barLp.height!=bottom){
                    barLp.height=bottom;
                    navigationBarBackground.setLayoutParams(barLp);
                }
                return insets;
            });
        }
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(false); s.setAllowFileAccessFromFileURLs(false); s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        if(Build.VERSION.SDK_INT>=26)s.setSafeBrowsingEnabled(true);
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView,false);
        webView.addJavascriptInterface(new PushBridge(),"AndroidPush");
        webView.addJavascriptInterface(new SpotFileBridge(),"AndroidSpotFiles");
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
                if(spotFilePicker!=null)spotFilePicker.onReceiveValue(null);
                spotFilePicker=callback;
                try{startActivityForResult(params.createIntent(),REQ_SPOT_IMPORT);return true;}
                catch(Exception e){spotFilePicker=null;callback.onReceiveValue(null);return false;}
            }
        });
        webView.addJavascriptInterface(new NativeVersionBridge(),"AndroidAppInfo");
        webView.addJavascriptInterface(new MigrationBridge(),"AndroidMigration");
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return openExternalIfNeeded(r.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return openExternalIfNeeded(Uri.parse(url));}
            @Override public void onPageFinished(WebView v,String url){
                super.onPageFinished(v,url);
                if(isLegacyLoginLanding(url)){v.loadUrl(ANDROID_HOME);return;}
                restoreLegacyPreferences(url);deliverPendingSpot();
                if(isTrustedAndroidPage(url)){
                    registerAdminBetaPush();
                    syncSavedWindPush();
                }
            }
        });
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        setContentView(root); if(Build.VERSION.SDK_INT>=35)root.requestApplyInsets(); readIntent(getIntent());
        // In-place update of the regular app: preserve existing WebView storage and settings.
        migrationOpen=false;
        webView.loadUrl(ANDROID_HOME);
    }
    // v0.77 RC: reconnect only existing wind-alarm installations; never create new
    // alarms or identities. At most once per 12 h after success; retry errors after
    // 2 min. The health preference stores status codes only, never secrets or tokens.
    private volatile boolean windPushSyncInProgress=false;
    private void syncSavedWindPush(){
        if(getPackageName().endsWith(".stage")||windPushSyncInProgress)return;
        SharedPreferences saved=getSharedPreferences(PushRegistrar.PREFS,MODE_PRIVATE);
        final String id=saved.getString("id","");
        final String secret=saved.getString("secret","");
        if(id==null||secret==null||id.length()<10||secret.length()<20)return;
        final SharedPreferences health=getSharedPreferences("kb_push_sync_v077",MODE_PRIVATE);
        final long now=System.currentTimeMillis();
        if(now-health.getLong("lastSuccess",0L)<12L*60*60*1000L)return;
        if(now-health.getLong("lastAttempt",0L)<2L*60*1000L)return;
        if(Build.VERSION.SDK_INT>=33 &&
           checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
            health.edit().putString("result","notifications-not-permitted").apply();
            // Existing alarm users may be prompted, at most once per 30 days.
            if(now-health.getLong("lastPrompt",0L)>30L*24*60*60*1000L){
                health.edit().putLong("lastPrompt",now).apply();
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_RECONNECT_NOTIFICATIONS);
            }
            return;
        }
        windPushSyncInProgress=true;
        health.edit().putLong("lastAttempt",now).apply();
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null||task.getResult().isEmpty()){
                health.edit().putString("result","firebase-token-failed").apply();
                windPushSyncInProgress=false;
                return;
            }
            PushRegistrar.sendSavedToken(this,task.getResult(),(ok,msg)->{
                SharedPreferences.Editor edit=health.edit()
                  .putString("result",ok?"ok":"alarm-server-rejected");
                if(ok)edit.putLong("lastSuccess",System.currentTimeMillis());
                edit.apply();
                windPushSyncInProgress=false;
            });
        });
    }
    // Admin-push registration is a separate, admin-authorized flow from wind alarms.
    // Retry transient failures when the authenticated WebView is loaded again.
    private volatile boolean adminPushRegistrationInProgress = false;
    private void registerAdminBetaPush(){
        final SharedPreferences p=getSharedPreferences("kb_beta_admin_push_v073",MODE_PRIVATE);
        final long now=System.currentTimeMillis();
        if(adminPushRegistrationInProgress)return;
        // Do not send a fresh token every navigation after a successful registration.
        if(now-p.getLong("lastSuccess",0L)<6L*60*60*1000L)return;
        // Failed registrations must never block retry for six hours.
        if(now-p.getLong("lastFailure",0L)<2L*60*1000L)return;
        adminPushRegistrationInProgress=true;
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null||task.getResult().isEmpty()){
                adminPushRegistrationFailure(p,"firebase-token");
                return;
            }
            final String token=task.getResult();
            new Thread(()->{
                HttpURLConnection c=null;
                try {
                    // WebView session and Chrome browser sessions are independent.
                    // The server will reject non-admin sessions; never bypass that check.
                    String cookie=CookieManager.getInstance().getCookie(ANDROID_HOME);
                    if(cookie==null||cookie.isEmpty()){
                        adminPushRegistrationFailure(p,"no-app-session");
                        return;
                    }
                    c=(HttpURLConnection)new URL("https://api.kitebuddies-nord.de/web-beta/admin-push-register.php").openConnection();
                    c.setConnectTimeout(8000);c.setReadTimeout(8000);
                    c.setRequestMethod("POST");c.setDoOutput(true);
                    c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                    c.setRequestProperty("X-KB-Android-Admin","1");
                    c.setRequestProperty("Cookie",cookie);
                    byte[] body=new JSONObject().put("token",token).toString().getBytes(StandardCharsets.UTF_8);
                    c.setFixedLengthStreamingMode(body.length);
                    try(OutputStream out=c.getOutputStream()){out.write(body);}
                    int result=c.getResponseCode();
                    if(result==200){
                        p.edit().putLong("lastSuccess",System.currentTimeMillis())
                          .remove("lastFailure").putString("lastResult","ok").apply();
                        // Only a server-authorized admin may be prompted.
                        if(Build.VERSION.SDK_INT>=33 &&
                           checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED){
                            runOnUiThread(()->requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_ADMIN_NOTIFICATIONS));
                        }
                    }else{
                        adminPushRegistrationFailure(p,"http-"+result);
                    }
                }catch(Exception e){
                    // Keep errors diagnosable without writing FCM tokens or cookies to logs.
                    adminPushRegistrationFailure(p,"network-"+e.getClass().getSimpleName());
                }finally{
                    if(c!=null)c.disconnect();
                    adminPushRegistrationInProgress=false;
                }
            },"kb-beta-admin-push").start();
        });
    }
    private void adminPushRegistrationFailure(SharedPreferences p,String status){
        p.edit().putLong("lastFailure",System.currentTimeMillis())
         .putString("lastResult",status).apply();
        adminPushRegistrationInProgress=false;
    }
    // The existing login may land on /web-beta/index.php after authentication.
    // Redirect only browser login landings. ANDROID_HOME itself must never redirect
    // to itself, otherwise /web-beta/android.php would create a reload loop.
    private boolean isLegacyLoginLanding(String url){
        try{Uri u=Uri.parse(url);if(!"https".equalsIgnoreCase(u.getScheme())||
            !"api.kitebuddies-nord.de".equalsIgnoreCase(u.getHost()))return false;
            String p=u.getPath();return "/web-beta/index.php".equals(p)||"/web-beta/".equals(p);
        }catch(Exception e){return false;}
    }
    private boolean isTrustedAndroidPage(String url){
        try{Uri u=Uri.parse(url);return "https".equalsIgnoreCase(u.getScheme())
          &&"api.kitebuddies-nord.de".equalsIgnoreCase(u.getHost())
          &&"/web-beta/android.php".equals(u.getPath());}catch(Exception e){return false;}
    }
    private boolean openExternalIfNeeded(Uri u){
        if(u==null)return true;
        String scheme=u.getScheme();
        if("about".equalsIgnoreCase(scheme))return false;
        if("https".equalsIgnoreCase(scheme)&&"api.kitebuddies-nord.de".equalsIgnoreCase(u.getHost())
           &&u.getPath()!=null&&u.getPath().startsWith("/web-beta/"))return false;
        if("https".equalsIgnoreCase(scheme)||"http".equalsIgnoreCase(scheme)
           ||"mailto".equalsIgnoreCase(scheme)||"tel".equalsIgnoreCase(scheme)){
            try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
            return true;
        }
        return true;
    }
    private void restoreLegacyPreferences(String url){
        if(!isTrustedAndroidPage(url))return;
        final SharedPreferences prefs=getSharedPreferences(MIGRATION_PREFS,MODE_PRIVATE);
        if(!prefs.getBoolean("collected",false)||prefs.getBoolean("completed",false))return;
        final String data=prefs.getString("payload","{}");
        if(data==null||data.length()>600000)return;
        String js="(function(){try{var obj=JSON.parse("+JSONObject.quote(data)+");"
           +"Object.keys(obj).forEach(function(k){if(localStorage.getItem(k)===null)localStorage.setItem(k,obj[k]);});"
           +"return 'ok';}catch(e){return 'failed';}})()";
        webView.evaluateJavascript(js,(result)->{
            if(!"\"ok\"".equals(result))return;
            prefs.edit().putBoolean("completed",true).remove("payload").apply();
            webView.reload();
        });
    }
    private final class NativeVersionBridge {
        @JavascriptInterface public int getVersionCode(){
            try {return getPackageManager().getPackageInfo(getPackageName(),0).versionCode;}
            catch(Exception e){return 79;}
        }
        @JavascriptInterface public String getVersionName(){
            try {return getPackageManager().getPackageInfo(getPackageName(),0).versionName;}
            catch(Exception e){return "0.77 Beta RC1";}
        }
    }
    private final class MigrationBridge {
        @JavascriptInterface public void save(String payload){
            if(!migrationOpen)return;
            migrationOpen=false;
            if(payload==null||payload.length()>600000)payload="{}";
            getSharedPreferences(MIGRATION_PREFS,MODE_PRIVATE).edit()
                .putString("payload",payload).putBoolean("collected",true).apply();
            runOnUiThread(()->webView.loadUrl(ANDROID_HOME));
        }
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);readIntent(i);deliverPendingSpot();}
    private void readIntent(Intent i){if(i!=null){String k=i.getStringExtra("kb_spot_key");if(k!=null&&!k.isEmpty())pendingSpotKey=k;}}
    private void deliverPendingSpot(){if(webView==null||pendingSpotKey.isEmpty()||!isTrustedAndroidPage(webView.getUrl()))return;String k=pendingSpotKey;pendingSpotKey="";webView.evaluateJavascript("window.KBOpenAlarmSpot&&window.KBOpenAlarmSpot("+JSONObject.quote(k)+")",null);}
    private void jsResult(boolean ok,String msg){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript("window.KBPushNativeResult&&window.KBPushNativeResult("+(ok?"true":"false")+","+JSONObject.quote(msg)+")",null);});}
    private void connectNow(String id,String secret,String version){
        PushRegistrar.saveCredentials(this,id,secret,version);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null){jsResult(false,"Firebase konnte keinen Push-Token erzeugen.");return;}
            PushRegistrar.sendToken(this,id,secret,version,task.getResult(),this::jsResult);
        });
    }
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==REQ_NOTIFICATIONS){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)connectNow(pendingId,pendingSecret,pendingVersion);else jsResult(false,"Benachrichtigungen wurden nicht erlaubt.");}
        if(req==REQ_RECONNECT_NOTIFICATIONS){
            if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)syncSavedWindPush();
            else getSharedPreferences("kb_push_sync_v077",MODE_PRIVATE).edit().putString("result","permission-denied").apply();
        }}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQ_SPOT_IMPORT){
            ValueCallback<Uri[]> callback=spotFilePicker;spotFilePicker=null;
            if(callback!=null)callback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode,data));
        }
    }
    private final class SpotFileBridge {
        @JavascriptInterface public boolean shareJson(String json,String filename){
            if(json==null||json.length()<16||json.length()>1048576)return false;
            // Share only a user-confirmed, structured spot JSON file. No private app files.
            if(!json.contains("\"kitebuddies-spot-share\""))return false;
            final String safeFile="Kitebuddies-Spots-"+System.currentTimeMillis()+".json";
            runOnUiThread(()->{
                try{
                    File folder=new File(getCacheDir(),"shared_spots");
                    if(!folder.isDirectory()&&!folder.mkdirs())throw new java.io.IOException("Share directory unavailable");
                    File output=new File(folder,safeFile);
                    try(FileOutputStream out=new FileOutputStream(output)){
                        out.write(json.getBytes(StandardCharsets.UTF_8));
                    }
                    Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",output);
                    Intent send=new Intent(Intent.ACTION_SEND);
                    send.setType("application/json");
                    send.putExtra(Intent.EXTRA_STREAM,uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(send,"Kitebuddies Spots teilen"));
                }catch(Exception e){
                    if(webView!=null)webView.evaluateJavascript("alert('Datei konnte nicht geteilt werden. Bitte Export im Browser verwenden.')",null);
                }
            });
            return true;
        }
    }
    private final class PushBridge {
        @JavascriptInterface public void setTone(String tone){
            if(tone==null||!tone.matches("soft|classic|strong|silent"))tone="soft";
            getSharedPreferences("kb_alarm_audio_v059", MODE_PRIVATE).edit().putString("tone",tone).apply();
        }
        @JavascriptInterface public void connect(String id,String secret,String version){
            if(getPackageName().endsWith(".stage")){
                jsResult(false,"Push ist in der Spot-Test-App deaktiviert. Nutze die reguläre App für Alarme.");
                return;
            }
            if(id==null||secret==null||id.length()<10||secret.length()<20){jsResult(false,"Ungültige anonyme Alarm-ID.");return;}
            pendingId=id;pendingSecret=secret;pendingVersion=(version==null||version.isEmpty())?"0.60 Beta":version;
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS); else connectNow(pendingId,pendingSecret,pendingVersion);
            });
        }
    }
}
