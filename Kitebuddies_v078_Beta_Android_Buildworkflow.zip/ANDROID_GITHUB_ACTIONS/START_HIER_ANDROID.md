# Android v0.78 Beta – Upgrade der bestehenden RC4

**Die APK ist noch nicht gebaut.** Der GitHub-Workflow baut das bestehende, signierte native RC4-Projekt aus dem verifizierten Quellarchiv auf v0.78 Beta (`versionCode 83`) um. Der vorhandene WebView-Start `/web-beta/android.php`, Firebase-Tokenregistrierung, mehrere Alarm-Pushs und Dateiimport/-export bleiben unverändert.

## Vorgehen

1. **Web-/iOS-Release erst gemeinsam mit der Android-App freigeben.** Der Android-Wrapper lädt `/web-beta/android.php`, das bei Produktivübernahme das gemeinsame `app-template.php` aus v0.78 nutzt.
2. Auf GitHub im Repo `janluethje1975-bit/kitebuddies-android` die zwei neuen Dateien unter `.github/workflows/` anlegen: `build-v078-beta.yml`, `patch_v078.py`. Bestehende Workflows/RC4-ZIP nicht verändern. Die vorhandenen Secrets `KB_KEYSTORE_B64` und `KB_KEYSTORE_PASSWORD` werden nur im GitHub-Runner gelesen, nicht in Dateien geteilt.
3. GitHub Actions → **Kitebuddies v0.78 Beta Android (v83)** → Run workflow. Nach Erfolg `Kitebuddies-v078-Beta-signed-TEST` (Workflow-Artefakt) herunterladen.
4. Die APK aus dem Workflow-Artefakt vor der Verteilung auf einem Android-Tester über der bestehenden RC4 installieren. Prüfen: App-Daten bleiben, Login, Firebase-Benachrichtigungen, Spotimport/-export, GPS, A/B und Feedback.
5. Erst nach Prüfung die APK nach `/kitebuddies-api/updates/pro/` laden und das im Build erzeugte `v078_UPDATE_MANIFEST_NICHT_AUTOMATISCH_VEROEFFENTLICHEN.json` nach Freigabe als Update-Manifest verwenden. Keine automatischen Updates vor Freigabe.

**Nicht im Container möglich:** Android SDK/Gradle-Build, Signierung und GitHub Actions Ausführung. Die GitHub-Verbindung verweigert das Schreiben (403).
