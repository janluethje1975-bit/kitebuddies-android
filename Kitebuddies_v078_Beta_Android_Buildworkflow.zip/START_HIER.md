# Kitebuddies Nord Forecast Pro – v0.78 Beta | Web/iOS & Android

**Ausgangsstand:** v0.78-T11 wurde im Pilot vom Nutzer auf dem Live-Server getestet; A/B, GPS, Spotmarker und zentrale Feedbackspeicherung laufen. Die v0.77 Beta RC4 bleibt bis zur Freigabe die produktive Grundlage.

## ZIP-Inhalt

- `WEB_IOS/TEST_PARALLEL/`: **zuerst** in `/kitebuddies-api/web-beta/` hochladen. Bestehende v0.77-Dateien (`index.php`, `android.php`, `app-template.php`, `auth.php`) **nicht überschreiben**. Neuer Testzugang: `https://api.kitebuddies-nord.de/web-beta/v078-beta.php`. Neue Testdiagnose: `/web-beta/v078-beta-check.php` (nur angemeldet).
- `WEB_IOS/PRODUKTIV_NACH_FREIGABE/`: **erst nach erfolgreichem Test und einer Datensicherung** in `/kitebuddies-api/web-beta/` hochladen. Diese Variante enthält die finale `app-template.php` für die vorhandenen `index.php` und `android.php` und überschreibt damit die bestehende Web/iOS- und Android-Weboberfläche. 
- `ANDROID_GITHUB_ACTIONS/`: GitHub Actions Buildworkflow, Buildquellen- und Prüfanleitung. Es ist **keine APK** im ZIP, weil keine Android-SDK/Gradle-Buildumgebung und keine Schreibberechtigung auf GitHub in dieser Sitzung verfügbar waren.

## Funktionsstand v0.78

- iOS Safe Area, GPS-Standort mit Genauigkeitskreis, 3-Sekunden-Geste zum Spot-Anlegen.
- Forecast A unverändert, Forecast B als bevorzugte Meeres-Rasterzelle; keine unterschiedliche Modellzusammensetzung zulassen; nicht vergleichbare B-Stunden bleiben ausgeblendet.
- Einheitliche Filter-/Zeitraumleiste in Spotkarte und Vorhersage mit A/B, Anheften und Wind-Overlay.
- Gecachte, schrittweise A/B-Spotmarker, transparenter Rückfall auf A; Alarme/Push bleiben Forecast A.
- Zentrale Feedback-Snapshots mit 7-Tage-Kalender, Session-Zeitraum, unabhängigen Sternen für A/B (`null`=nicht bewertet), Windrichtungsvergleich und optionalen Messwerten.

## Sicherheits- und Migrationshinweise

1. Die Datenbank bzw. das private Dateiverzeichnis `kitebuddies-ab-feedback-pilot` mit `secret.key` und `ENABLE-V078-AB` **unbedingt unverändert lassen**. Der neue Endpunkt `v078-beta-feedback.php` nutzt den gleichen privaten Speicher; bereits gespeicherte Bewertungen bleiben erhalten. **Keine** Secret-Datei hochladen oder in die ZIP aufnehmen.
2. Die Version verwendet für den geplanten Produktivstart die vorhandene Web-/iOS-PWA-URL `/web-beta/index.php` und Android-URL `/web-beta/android.php`. Es ist keine neue Paketkennung und kein neues Lizenzsystem nötig.
3. `auth.php`, Lizenzverwaltung, Alarm- und Firebase-Endpunkte, Wetter-API, alte v0.77-Wrapperdateien (`index.php`, `android.php`) bleiben unverändert.
4. Bestehende `pro-*.js`, `kb-unified-forecast.js`, Wind-Overlay, CSS, Icons, `manifest.webmanifest` müssen bereits in `web-beta` vorhanden sein, wie im T11-Pilot.
5. **Datenschutz:** Vor Freigabe an alle Tester noch Aufbewahrung/Löschfristen und Datenschutzhinweis festlegen; die App speichert pseudonymisierte Testerkennungen, Session-Zeiträume, Messwerte und Prognosesnapshots.
6. Bekannte Einschränkung: Berechnete A/B-Vergleiche liefern keine verlässlichen Modelllauf-IDs; Vergleich wird auf Modell-, Zeit- und Cachegleichheit geprüft, jedoch nicht eine identische Modellinitialisierung garantiert.
7. Web/iOS und Android nutzen dieselbe PHP-/JS-Oberfläche. Eine v0.78-Android-APK erfordert **GitHub Actions + bestehende Signierschlüssel** und muss denselben Zertifikat-Fingerprint wie RC4 besitzen, sonst kann die bestehende App nicht aktualisiert werden.

## Reihenfolge für den Live-Test

1. **Backup**: `app-template.php`, die übrigen Beta-Serverdateien sowie den privaten Feedbackspeicher separat sichern.
2. `TEST_PARALLEL/` hochladen. Anmeldung über die reguläre Beta wie gehabt; den separaten Testzugang danach öffnen. Aufgrund der unveränderten `auth.php` kehrt der normale Login nach einer abgelaufenen Sitzung zunächst zur v0.77-Startseite zurück. Dann den Testzugang erneut aufrufen.
3. `/web-beta/v078-beta-check.php` prüfen: `ok:true`, `allFilesPresent:true`, `feedbackReady:true`. Parallel testen: SPO/Fehmarn/Rømø, A/B/A/B, Marker, GPS, Filter, Sessionbewertungen (mit vorab archivierten Prognosen). Als Testnutzer anmelden.
4. Den Android-Workflow `build-v078-beta.yml` in `.github/workflows/` hochladen und über GitHub Actions manuell starten. Die *signierte* APK aus dem Workflow-Artefakt laden und über bestehender RC4 installieren, **nicht** eine zweite App installieren. Tests: Login, GPS, A/B, Feedback, Android-Push, Alarme, Dateiexport.
5. **Erst danach** nach Freigabe `PRODUKTIV_NACH_FREIGABE/` hochladen und Cache/PWA neu laden. Vorhandene `index.php` und `android.php` bleiben liegen. Das Android-Update-Manifest darf nur nach einem echten signierten und geprüften APK-Build veröffentlicht werden.
6. Fehler/Rollback: Das zuvor gesicherte `app-template.php` zurückkopieren; die neuen v0.78-JS-Dateien können vorerst liegen bleiben, da sie ohne Template nicht geladen werden. Feedbackspeicher und Pilotdateien nicht löschen.

## Versionsnummern

- Web/iOS: **v0.78 Beta** / JS Web-VersionCode **83**.
- Android geplant: `applicationId de.kitebuddies.forecast.prc`, `versionCode 83`, `versionName 0.78 Beta`, gleiche Signatur wie RC4 (v82).
- Android APK: **nicht lokal gebaut**. Veröffentlichungs- und Update-Manifeste sind kein APK-Ersatz.
