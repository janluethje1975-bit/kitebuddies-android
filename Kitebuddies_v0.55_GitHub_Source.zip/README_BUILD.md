# Kitebuddies Nord Forecast Pro v0.55 Beta – Statusleisten-Fix

Basis: v0.54 Beta.

Änderungen:
- VersionCode 55 / VersionName 0.55 Beta
- minSdk 24
- Android-Systemstatusleiste erhält wieder einen eigenen dunklen Bereich oberhalb der WebView.
- Statusleisten-Symbole bleiben hell.
- WebView wird um die tatsächliche Statusleistenhöhe nach unten versetzt; keine Überlagerung mit Kitebuddies-Header mehr.
- Forecast-, Karten-, Weather-, Wind-, Firebase-/FCM- und Alarmregel-Logik unverändert gegenüber v0.54.
- Integrierte Anleitung auf v0.55 aktualisiert.

Paket-ID bleibt: de.kitebuddies.forecast.prc
Der Build muss weiterhin mit dem permanenten Kitebuddies-SigningKey signiert werden.
