package de.kitebuddies.forecast.prc;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONObject;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class PushRegistrar {
    static final String API = "https://api.kitebuddies-nord.de/alarm/index.php";
    static final String PREFS = "kb_push_native";
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    interface Callback { void done(boolean ok, String message); }
    static void saveCredentials(Context c,String id,String secret,String appVersion){
        c.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString("id",id).putString("secret",secret).putString("appVersion",appVersion).apply();
    }
    static void sendSavedToken(Context c,String token,Callback cb){
        SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        String id=p.getString("id",""); String secret=p.getString("secret",""); String ver=p.getString("appVersion","0.55 Beta");
        if(id.isEmpty()||secret.isEmpty()){if(cb!=null)cb.done(false,"Alarm-ID noch nicht mit Push verbunden.");return;}
        sendToken(c,id,secret,ver,token,cb);
    }
    static void sendToken(Context c,String id,String secret,String appVersion,String token,Callback cb){
        EXEC.execute(() -> {
            boolean ok=false; String msg="Push-Token konnte nicht gespeichert werden.";
            try{
                JSONObject j=new JSONObject(); j.put("action","push-token"); j.put("installId",id); j.put("installSecret",secret); j.put("appVersion",appVersion); j.put("pushToken",token);
                HttpURLConnection h=(HttpURLConnection)new URL(API).openConnection();
                h.setConnectTimeout(15000); h.setReadTimeout(15000); h.setRequestMethod("POST"); h.setDoOutput(true); h.setRequestProperty("Content-Type","application/json; charset=utf-8");
                byte[] b=j.toString().getBytes(StandardCharsets.UTF_8); h.setFixedLengthStreamingMode(b.length);
                try(OutputStream o=h.getOutputStream()){o.write(b);} int code=h.getResponseCode(); ok=code>=200&&code<300; msg=ok?"Push bereit":"Alarmserver antwortet mit HTTP "+code; h.disconnect();
            }catch(Exception e){msg="Push-Registrierung fehlgeschlagen: "+e.getClass().getSimpleName();}
            if(cb!=null)cb.done(ok,msg);
        });
    }
}
