Kitebuddies Nord Forecast Pro Web/iOS-PWA v0.64 Beta
Basis: v0.63. Veränderungen: Windlegende links unten und kompakt; Spots im Vergleich einklappbar plus Favoritenfilter; Bestes Kitefenster zeigt Grün/Rot/? statt ausschließlich grüne Häkchen.

Server: nur die enthaltenen Dateien im bestehenden `/kitebuddies-api/web-beta/` hochladen (Ordner `web-beta` nicht doppelt anlegen). Bereits existierende Nutzer-/Admin-/Lizenzdaten und Serverkonfigurationen nicht überschreiben; vorab sichern.
Zuletzt `web-version.json` hochladen, damit bestehende PWA-Installationen erst nach dem vollständigen Update den Versionswechsel erkennen.
Web-PWA/iOS-In-App-Alarm ist nicht dasselbe wie garantiertes Hintergrund-Push.
Die Dateien sind fertig vorbereitet, aber ein produktiver Upload erfolgte hier nicht.
