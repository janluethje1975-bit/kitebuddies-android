const fs=require('fs'),vm=require('vm');const root='/mnt/data/v074_dev/web-beta';
const mixer=fs.readFileSync(root+'/kb-unified-forecast.js','utf8');
const overlay=fs.readFileSync(root+'/pro-wind-overlay.js','utf8');
const gear=fs.readFileSync('/mnt/data/v074_dev/gear-test-target.js','utf8');
const ctx={console,window:{KBRegionalModels:{region:()=> 'nordic',weight:(key,r,h)=>key==='dwd_icon_seamless'?1.35:key==='dmi_seamless'?(h<=60?1.3:0):key==='ecmwf_ifs025'?1.2:1,select:()=>({models:[{key:'dwd_icon_seamless',server:'dwd'},{key:'dmi_seamless',server:'dmi'},{key:'ecmwf_ifs025',server:'ecmwf'},{key:'gfs_seamless',server:'gfs'}]})}},Date,URLSearchParams,Math,Number,Promise,Map,Set};
ctx.KBRegionalModels=ctx.window.KBRegionalModels;vm.createContext(ctx);vm.runInContext(mixer,ctx);ctx.KBUnifiedForecast=ctx.window.KBUnifiedForecast;
let o=ctx.window.KBUnifiedForecast.combine([{wind:10,dir:350,weight:2,gust:13},{wind:14,dir:10,weight:1,gust:16}]);
if(Math.abs(o.wind-11.333333333)>1e-6||Math.abs(o.gust-14)>1e-6||o.dir>5&&o.dir<355)throw Error('circular or speed blend failed');
console.log('PASS weighted vector mix',JSON.stringify(o));
// Extract only function requestPackage (pure async with stubbed fetch) and verify same weighted grid logic.
const st=overlay.indexOf('async function requestPackage(grid,signal){');const en=overlay.indexOf('\nasync function ensurePackage(){',st);
if(st<0||en<0)throw Error('requestPackage not found');
const names={dwd:9,dmi:14,ecmwf:12,gfs:16};
ctx.forecastDate=t=>new Date(t);ctx.packageKey=grid=>'test';
ctx.fetch=async url=>{const m=new URL('https://test.invalid'+url).searchParams.get('model'),v=names[m];return{ok:true,json:async()=>({ok:true,data:[{hourly:{time:['2026-11-07T12:00:00','2026-11-07T13:00:00'],wind_speed_10m:[v,v+1],wind_direction_10m:[350,355]}}]})}};
vm.runInContext(overlay.slice(st,en),ctx);
// Date.now 2026+? query passed static in past, DMI modelWeight uses Math.max(0,neg) and included.
(async()=>{const result=await vm.runInContext('requestPackage({points:[{lat:54.3,lon:8.6}],cols:1,rows:1,west:8.6,east:8.6,south:54.3,north:54.3},null)',ctx);
if(result.modelCount!==4||!Number.isFinite(result.winds[0][0]))throw Error('grid model mix not populated');
const expected=ctx.window.KBUnifiedForecast.combine(Object.keys(names).map(k=>({wind:names[k],dir:350,weight:ctx.window.KBRegionalModels.weight(({dwd:'dwd_icon_seamless',dmi:'dmi_seamless',ecmwf:'ecmwf_ifs025',gfs:'gfs_seamless'})[k],'nordic',0)}))).wind;
if(Math.abs(expected-result.winds[0][0])>.01)throw Error('grid and detail mixer inconsistent');
console.log('PASS overlay grid blend',result.winds[0][0],result.modelCount,'models');
// Equipment recommendations: both types in same array, independent of legacy kite type.
const store={'kb_owned_kites_v074':JSON.stringify([{name:'Soul',size:10,type:'soft'},{name:'Evo',size:13,type:'tube'}])};
ctx.localStorage={getItem:k=>store[k]||null,setItem:(k,v)=>store[k]=v};ctx.safeJSON=(raw,fb)=>{try{return JSON.parse(raw)}catch{return fb}};
ctx.getProfile=()=>({weight:85,level:0,board:'normalTwintip',kiteType:'tube'});ctx.gustForProfile=()=>({value:0,label:'konstant'});ctx.calculateKiteFor=(wind,w,l,t)=>({displayedExactSize:t==='soft'?10:13});ctx.$=()=>null;ctx.state={consensus:[]};
vm.runInContext(gear,ctx);
const kk=vm.runInContext('kbGearRecommendations({wind:16,gust:19,dir:135})',ctx);
if(kk.length!==2||!kk.every(k=>k.fit)||kk[0].type===kk[1].type)throw Error('mixed gear failed');
console.log('PASS both soft and tube kites simultaneously',kk.map(k=>k.name).join(', '));
})().catch(e=>{console.error(e);process.exitCode=1});
