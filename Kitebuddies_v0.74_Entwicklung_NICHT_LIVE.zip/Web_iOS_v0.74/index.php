<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

$userId = kb_web_require_login();
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header("Referrer-Policy: same-origin");

$file = __DIR__ . '/app.html';
$html = @file_get_contents($file);
if ($html === false) {
    http_response_code(500);
    exit('Web-App konnte nicht geladen werden.');
}
$html = str_replace(
    '__KB_WEB_USER_ID__',
    htmlspecialchars($userId, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'),
    $html
);
echo $html;
