<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate');

kb_web_start_session();
$userId = kb_web_current_user_id();

if ($userId === null || !kb_web_user_is_active($userId)) {
    http_response_code(401);
    echo json_encode(['ok'=>false,'active'=>false], JSON_UNESCAPED_SLASHES);
    exit;
}

$versionCode = isset($_GET['versionCode']) ? (int)$_GET['versionCode'] : 0;
$versionName = trim((string)($_GET['versionName'] ?? ''));
if ($versionCode < 0 || $versionCode > 1000000) $versionCode = 0;
if (mb_strlen($versionName) > 40) $versionName = mb_substr($versionName, 0, 40);

$now = gmdate('c');

if ($versionCode > 0 || $versionName !== '') {
    kb_update_web_users(function (&$data) use ($userId, $versionCode, $versionName, $now): array {
        if (!isset($data['users'][$userId]) || !is_array($data['users'][$userId])) {
            return [];
        }

        if ($versionCode > 0) $data['users'][$userId]['webVersionCode'] = $versionCode;
        if ($versionName !== '') $data['users'][$userId]['webVersionName'] = $versionName;
        $data['users'][$userId]['lastSeenAt'] = $now;
        return [];
    });
}

echo json_encode([
    'ok'=>true,
    'active'=>true,
    'userId'=>$userId,
    'serverTime'=>$now
], JSON_UNESCAPED_SLASHES);
