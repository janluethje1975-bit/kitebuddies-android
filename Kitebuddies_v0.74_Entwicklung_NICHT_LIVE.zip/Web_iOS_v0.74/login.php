<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

kb_web_start_session();
header('Cache-Control: no-store, no-cache, must-revalidate');

if (kb_web_current_user_id() !== null) {
    $id = kb_web_current_user_id();
    if ($id !== null && kb_web_user_is_active($id)) {
        header('Location: ' . KB_WEB_HOME_PATH);
        exit;
    }
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    kb_web_require_csrf();

    $userId = strtoupper(trim((string)($_POST['userId'] ?? '')));
    $password = (string)($_POST['password'] ?? '');

    $result = kb_web_login($userId, $password);

    if (!empty($result['ok'])) {
        header('Location: ' . KB_WEB_HOME_PATH);
        exit;
    }

    // Bewusst gleiche Meldung für unbekannte ID, falsches Passwort und Sperre.
    $error = 'Anmeldung nicht möglich. Bitte prüfe Deine Zugangsdaten oder wende Dich an den Administrator.';
}

$csrf = kb_web_csrf_token();
?>
<!doctype html>
<html lang="de">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title>Kitebuddies Nord Forecast Pro – Beta Login</title>
<link rel="manifest" href="/web-beta/manifest.webmanifest">
<meta name="theme-color" content="#0d1319">
<meta name="mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="Kitebuddies">
<link rel="apple-touch-icon" href="/web-beta/icons/apple-touch-icon.png">

<style>
*{box-sizing:border-box}
body{margin:0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:20px;background:#0d1319;color:#eef3f7;font-family:system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
.card{width:min(100%,430px);background:#17212a;border:1px solid #2c3b48;border-radius:18px;padding:24px;box-shadow:0 18px 50px rgba(0,0,0,.28)}
.logo{font-size:13px;letter-spacing:.12em;text-transform:uppercase;color:#7fb2e8;font-weight:800}
h1{font-size:25px;line-height:1.15;margin:10px 0 8px}
p{color:#b4c0ca;line-height:1.45}
label{display:block;font-weight:700;margin:16px 0 6px}
input{width:100%;padding:13px;border:1px solid #445768;border-radius:10px;background:#0b1218;color:#fff;font-size:16px}
button{width:100%;margin-top:20px;padding:13px 16px;border:0;border-radius:10px;background:#2f80ed;color:#fff;font-size:16px;font-weight:800}
.err{margin:14px 0;background:#4b2023;border:1px solid #73353a;padding:12px;border-radius:10px}
.small{font-size:12px;color:#83929e;margin-top:18px}
</style>
</head>
<body>
<div class="card">
<div class="logo">Kitebuddies Nord</div>
<h1>Forecast Pro Beta</h1>
<p>Geschützter Web-/iOS-Beta-Zugang.</p>

<?php if ($error): ?>
<div class="err"><?=kb_e($error)?></div>
<?php endif; ?>

<form method="post" autocomplete="on">
<input type="hidden" name="csrf" value="<?=kb_e($csrf)?>">

<label for="userId">User-ID</label>
<input id="userId" name="userId" required autocomplete="username" autocapitalize="characters" placeholder="WEB-KB-A1B2C3D4">

<label for="password">Passwort</label>
<input id="password" type="password" name="password" required autocomplete="current-password">

<button type="submit">Anmelden</button>
</form>

<div class="small">Beta-Zugang nur für freigeschaltete Tester.</div>
</div>

<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', function(){
    navigator.serviceWorker.register('/web-beta/service-worker.js', {scope:'/web-beta/'})
      .catch(function(err){ console.warn('PWA Service Worker konnte nicht registriert werden', err); });
  });
}
</script>

</body>
</html>
