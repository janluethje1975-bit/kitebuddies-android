<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

kb_web_start_session();
$userId = kb_web_current_user_id();
if ($userId === null || !kb_web_user_is_active($userId)) {
    http_response_code(401);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'unauthorized']);
    exit;
}

$configFile = __DIR__ . '/../license/data/web-config.php';
$config = is_file($configFile) ? include $configFile : null;
if (!is_array($config) || empty($config['weatherApiUrl']) || empty($config['weatherApiToken'])) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'web_weather_not_configured']);
    exit;
}

$allowed = [
    'action','model','latitude','longitude','hourly','daily',
    'forecast_days','timezone','cell_selection'
];
$params = [];
foreach ($allowed as $key) {
    if (isset($_GET[$key]) && !is_array($_GET[$key])) {
        $params[$key] = trim((string)$_GET[$key]);
    }
}

$action = $params['action'] ?? '';
if (!in_array($action, ['model','marine','catalog','thermics'], true)) {
    http_response_code(400);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok'=>false,'error'=>'invalid_action']);
    exit;
}

if ($action !== 'catalog') foreach (['latitude','longitude'] as $coord) {
    $v = $params[$coord] ?? '';
    if ($v === '' || strlen($v) > 2000 || !preg_match('/^[0-9.,+\-\s]+$/', $v)) {
        http_response_code(400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'error'=>'invalid_'.$coord]);
        exit;
    }
}

if (isset($params['forecast_days'])) {
    $days = (int)$params['forecast_days'];
    $params['forecast_days'] = (string)max(1, min(16, $days));
}
if (isset($params['hourly']) && !preg_match('/^[A-Za-z0-9_,]+$/', $params['hourly'])) {
    unset($params['hourly']);
}
if (isset($params['daily']) && !preg_match('/^[A-Za-z0-9_,]+$/', $params['daily'])) {
    unset($params['daily']);
}
if (isset($params['timezone']) && !preg_match('/^[A-Za-z0-9_+\/\-]+$/', $params['timezone'])) {
    $params['timezone'] = 'Europe/Berlin';
}
if (isset($params['cell_selection']) && !in_array($params['cell_selection'], ['nearest','sea','land'], true)) {
    unset($params['cell_selection']);
}

$params['token'] = (string)$config['weatherApiToken'];
// v0.69 optional UKMO/GEM add-on endpoint; core weather service remains unchanged.
$weatherBase = (string)$config['weatherApiUrl'];
if ($action === 'thermics') {
    $weatherBase = preg_replace('~kb-weather-api\.php$~', 'kb-thermics-v070.php', $weatherBase);
    if ($weatherBase === (string)$config['weatherApiUrl']) {http_response_code(503);header('Content-Type: application/json');echo json_encode(['ok'=>false,'error'=>'thermics_backend_not_configured']);exit;}
} elseif ($action === 'catalog' || ($action === 'model' && in_array($params['model'] ?? '', ['ukmo','gem'], true))) {
    $weatherBase = preg_replace('~kb-weather-api\.php$~', 'kb-models-v069.php', $weatherBase);
    if ($weatherBase === (string)$config['weatherApiUrl']) {
        http_response_code(503);header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok'=>false,'error'=>'regional_backend_not_configured']);exit;
    }
}
$url = rtrim((string)$weatherBase, '?') . '?' . http_build_query($params, '', '&', PHP_QUERY_RFC3986);

$status = 502;
$body = '';
$contentType = 'application/json; charset=utf-8';

if (function_exists('curl_init')) {
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CONNECTTIMEOUT => 5,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_FOLLOWLOCATION => false,
        CURLOPT_HTTPHEADER => ['Accept: application/json']
    ]);
    $result = curl_exec($ch);
    if ($result !== false) {
        $body = (string)$result;
        $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        $ct = (string)curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
        if ($ct !== '') $contentType = $ct;
    } else {
        $body = json_encode(['ok'=>false,'error'=>'weather_upstream_unreachable']);
    }
    curl_close($ch);
} else {
    $ctx = stream_context_create([
        'http' => [
            'method' => 'GET',
            'timeout' => 20,
            'ignore_errors' => true,
            'header' => "Accept: application/json\r\n"
        ]
    ]);
    $result = @file_get_contents($url, false, $ctx);
    if ($result !== false) {
        $body = (string)$result;
        $status = 200;
        if (!empty($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
            $status = (int)$m[1];
        }
    } else {
        $body = json_encode(['ok'=>false,'error'=>'weather_upstream_unreachable']);
    }
}

http_response_code($status > 0 ? $status : 502);
header('Content-Type: '.$contentType);
header('Cache-Control: no-store');
header('X-Content-Type-Options: nosniff');
echo $body;
