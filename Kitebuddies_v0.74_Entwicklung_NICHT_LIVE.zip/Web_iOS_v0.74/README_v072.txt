Web/iOS v0.72 Beta
Backup /web-beta/ then upload contents of web-beta/ into same remote folder, do not create web-beta/web-beta.
Prerequisite: /kitebuddies-api/kb-stations-v072.php deployed and web host supports outbound HTTPS for BrightSky/DMI.
Session login and weather-proxy.php unchanged. PWA cache version raised to 72.
