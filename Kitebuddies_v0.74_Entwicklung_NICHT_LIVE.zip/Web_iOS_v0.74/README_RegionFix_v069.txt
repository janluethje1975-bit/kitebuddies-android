Kitebuddies Nord Forecast v0.69 Beta – Region/Modellcache-Hotfix (Web/iOS)

A) Gesichert vorhandene /web-beta/app.html mit dieser app.html ersetzen.
B) KEIN Versionssprung: v0.69 bleibt erhalten.
C) Modellvergleich zeigt nun erkannte Region sowie Koordinaten.
D) Modellwechsel und Batch-Cache können nicht mehr DMI-Norddaten für Kapstadt als Modellset nutzen.
E) v0.69 Update-Loop-Fix ist enthalten.
F) UKMO/GEM nur wenn kb-models-v069.php serverseitig installiert und per Web-Proxy zugänglich.
G) Wetterdaten/Regionen mit echtem Safari-/Android-Test überprüfen.
