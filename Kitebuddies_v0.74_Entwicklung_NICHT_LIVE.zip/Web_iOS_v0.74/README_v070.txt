Kitebuddies v0.70: Thermik PRO und regionaler Cape-Doctor-Check. Details in Kitebuddies_v0.70_Beta_Hinweise.txt.
