<?php
declare(strict_types=1);

/*
 * Kitebuddies Web-/iOS-Beta Login – gemeinsame Authentifizierung.
 * Nutzt die bereits vorhandene Web-User-Verwaltung unter /license/data/.
 */

require_once __DIR__ . '/../license/data/admin-lib.php';
require_once __DIR__ . '/../license/data/web-users-lib.php';

const KB_WEB_SESSION_NAME = 'KBWEBSESSID';
const KB_WEB_LOGIN_PATH = '/web-beta/login.php';
const KB_WEB_HOME_PATH = '/web-beta/index.php';

function kb_web_start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }

    session_name(KB_WEB_SESSION_NAME);

    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/web-beta/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Strict'
    ]);

    session_start();
}

function kb_web_csrf_token(): string {
    if (empty($_SESSION['kb_web_csrf'])) {
        $_SESSION['kb_web_csrf'] = bin2hex(random_bytes(24));
    }
    return (string)$_SESSION['kb_web_csrf'];
}

function kb_web_require_csrf(): void {
    $posted = (string)($_POST['csrf'] ?? '');
    $stored = (string)($_SESSION['kb_web_csrf'] ?? '');

    if ($stored === '' || !hash_equals($stored, $posted)) {
        http_response_code(400);
        exit('Ungültige Anfrage.');
    }
}

function kb_web_current_user_id(): ?string {
    $id = (string)($_SESSION['kb_web_user_id'] ?? '');
    return kb_valid_web_user_id($id) ? $id : null;
}

function kb_web_user_is_active(string $userId): bool {
    $data = kb_read_web_users();
    $user = $data['users'][$userId] ?? null;
    return is_array($user) && (($user['status'] ?? '') === 'active');
}

function kb_web_require_login(): string {
    kb_web_start_session();

    $userId = kb_web_current_user_id();
    if ($userId === null || !kb_web_user_is_active($userId)) {
        $_SESSION = [];
        session_regenerate_id(true);
        header('Location: ' . KB_WEB_LOGIN_PATH);
        exit;
    }

    return $userId;
}

function kb_web_login(string $userId, string $password): array {
    $result = kb_verify_web_user_credentials($userId, $password);

    if (empty($result['ok'])) {
        return $result;
    }

    session_regenerate_id(true);
    $_SESSION['kb_web_user_id'] = $userId;
    $_SESSION['kb_web_logged_in_at'] = gmdate('c');

    kb_update_web_users(function (&$data) use ($userId): array {
        if (isset($data['users'][$userId]) && is_array($data['users'][$userId])) {
            $data['users'][$userId]['lastLoginAt'] = gmdate('c');
        }
        return [];
    });

    return ['ok' => true, 'userId' => $userId];
}

function kb_web_logout(): void {
    kb_web_start_session();
    $_SESSION = [];

    if (ini_get('session.use_cookies')) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params['path'],
            $params['domain'] ?? '',
            (bool)$params['secure'],
            (bool)$params['httponly']
        );
    }

    session_destroy();
}
