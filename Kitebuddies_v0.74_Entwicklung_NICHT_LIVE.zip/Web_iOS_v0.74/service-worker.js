const KB_WEB_VERSION_CODE = 74;
const KB_CACHE_PREFIX = 'kitebuddies-web-beta-static-v';
const KB_CACHE = KB_CACHE_PREFIX + KB_WEB_VERSION_CODE;

const STATIC_ASSETS = [
  '/web-beta/manifest.webmanifest',
  '/web-beta/web-version.json',
  '/web-beta/pro-weather-api.js',
  '/web-beta/pro-regional-models.js',
  '/web-beta/kb-unified-forecast.js',
  '/web-beta/pro-thermics.js',
  '/web-beta/kb-live-stations.js',
  '/web-beta/pro-wind-overlay.js',
  '/web-beta/pro-wind-overlay.css',
  '/web-beta/pro-coastline.js',
  '/web-beta/icons/icon-192.png',
  '/web-beta/icons/icon-512.png',
  '/web-beta/icons/apple-touch-icon.png'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(KB_CACHE)
      .then(cache => cache.addAll(STATIC_ASSETS.map(url => new Request(url, {cache:'reload'}))))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(
        keys
          .filter(k => k.startsWith(KB_CACHE_PREFIX) && k !== KB_CACHE)
          .map(k => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('message', event => {
  const data = event.data || {};

  if (data.type === 'KB_SKIP_WAITING') {
    self.skipWaiting();
    return;
  }

  if (data.type === 'KB_CLEAR_STATIC_CACHE') {
    event.waitUntil(
      caches.keys().then(keys => Promise.all(
        keys.filter(k => k.startsWith(KB_CACHE_PREFIX)).map(k => caches.delete(k))
      ))
    );
  }
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;

  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return;

  // Authentication, PHP, navigation, session and live weather must always use network.
  if (
    req.mode === 'navigate' ||
    url.pathname.endsWith('.php') ||
    url.pathname.includes('/weather-proxy') ||
    url.pathname.includes('/session-check')
  ) {
    event.respondWith(fetch(req, {cache:'no-store'}));
    return;
  }

  // Version manifest must always be fresh so an update can be detected.
  if (url.pathname === '/web-beta/web-version.json') {
    event.respondWith(fetch(req, {cache:'no-store'}));
    return;
  }

  if (STATIC_ASSETS.includes(url.pathname)) {
    event.respondWith(
      caches.match(req).then(cached => {
        const network = fetch(req, {cache:'no-cache'}).then(response => {
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(KB_CACHE).then(cache => cache.put(req, copy));
          }
          return response;
        }).catch(() => null);

        // Fast cached response, with background refresh.
        if (cached) {
          event.waitUntil(network);
          return cached;
        }

        return network.then(response => response || new Response('', {status:503}));
      })
    );
  }
});
