<?php
declare(strict_types=1);
require __DIR__ . '/auth.php';

kb_web_logout();
header('Location: /web-beta/login.php');
exit;
