Kitebuddies Nord Forecast Pro Web/iOS v0.71 Beta
Basiert auf v0.70 Web/iOS LayoutFix.

Die App-Anmeldung, PHP-Dateien, weather-proxy.php, Auth/Session, Serverpfade, Filter, Thermik und Service-Worker bleiben erhalten.
Neuerungen: Bei DWD-Windfeld werden Boeen nur bei gleicher DWD-Modellstunde und vergleichbarem Windwert gezeigt; andernfalls Boeen –; Nacht- und Confidence-Hinweise in der Spotvorschau; neue Anleitung/Update-Info.

Upload: Existierenden /web-beta/ Serverordner zuvor sichern. Den INHALT von web-beta/ aus diesem ZIP in den vorhandenen /web-beta/ Ordner hochladen; NICHT web-beta/web-beta/ anlegen. In PWA anschließend Update annehmen, ggf. neu öffnen.
