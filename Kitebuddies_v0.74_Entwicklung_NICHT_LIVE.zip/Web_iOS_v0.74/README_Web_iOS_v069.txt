Kitebuddies Nord Forecast Pro – Web/iOS v0.69 Beta

Vorsicht: Noch nicht produktiv ausgerollt. Die pro-regional-models.js enthält gemeinsame Modellregeln.
Neue UKMO/GEM-Modelle sind nur aktiv, wenn kb-models-v069.php auf dem Wetter-API-Server installiert ist.
Die bestehende Wetter-API, Benutzersitzungen, Push- und Shore-Logik bleiben bestehen.
Vor Upload: vollständige Sicherung des bestehenden /web-beta/ anlegen.

Pro-Thermik ist vorerst ein Architektur-Flag, noch keine Wetterkorrektur.
