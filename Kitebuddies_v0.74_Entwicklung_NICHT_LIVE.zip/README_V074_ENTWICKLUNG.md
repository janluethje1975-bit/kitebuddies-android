# Kitebuddies Nord Forecast Pro – v0.74 Entwicklungsstand

**Status:** Lokal implementiert und statisch / mit synthetischen Testdaten geprüft, **noch nicht auf Live-Web/iOS oder Android freigegeben**.

## Ziel
Konsistente Superforecast-Prognose aus denselben verfügbaren, regional gewichteten Modellen für:
- Spotkarte / Marker und Vorschau,
- Spotvergleich und detaillierten Forecast,
- Windfeld/Windpfeile (dieselbe Gewichtungsformel; räumlich interpoliertes Raster),
- KiteScore, Confidence, Shore und In-App-Alarme,
- Kitegrößenempfehlungen inklusive eigener Tube- **und** Softkites gleichzeitig.

## Änderungen
1. `kb-unified-forecast.js`: Mathematisch gemeinsam verwendete gewichtete Windgeschwindigkeit, Böen und zirkuläre Windrichtung. Dynamische historische Lerngewichte derzeit **nicht** aktiv – diese Daten müssen zunächst validiert werden.
2. `app.html` / `index.html`: Karten-Windwert und Score/Confidence kommen ausschließlich aus dem Superforecast-Snapshot (zur gewählten Stunde); keine ersetzenden DWD-Rasterwerte, keine ECMWF-Ersatzübersicht, kein gesonderter Zweimodell-Confidence-Wert.
3. `pro-wind-overlay.js`: Berechnet das Kartenraster aus DWD/DMI/ECMWF/GFS (in Nordeuropa, soweit verfügbar); gleiche Modellgewichte wie Detailprognose. Maximal zwei Wetteranfragen parallel, Rasterpakete in den Cache, keine teure Neubewertung bei jeder Kartenbewegung. Mindestens zwei Modelle erforderlich; sonst Windfeld als nicht verfügbar behandeln. Pfeile zeigen räumlich interpolierte Windverhältnisse; Werte direkt auf dem Spot werden aus dem jeweiligen Spot-Forecast geliefert.
4. Bei Öffnen des Spot-Forecasts aus der Karte wird der auf der Karte gewählte Zeitpunkt bevorzugt, sofern er im gewählten Forecast-Zeitraum liegt.
5. In-App-Alarme verwenden die Forecast-Zeitreihe aus dem gemeinsamen Spot-Bundle; keine separate Windformel. **Der serverseitige Hintergrund-Pushdienst ist noch nicht auditiert/vereinheitlicht** und wird deshalb im UI nicht als „bereit“ ausgegeben.
6. „Meine eigenen Kites“ unter Tools: mehrere Kites beider Arten (Modell, Größe, Tube/Soft) lokal speichern und entfernen; alle Einträge gegen dieselbe Forecaststunde rechnerisch bewerten. Bestehende Kite-Rechnerprofile bleiben erhalten. Empfehlungen sind Orientierung und **keine Windbereichszusicherung**; Herstellerangaben / Böen / Können haben Vorrang.
7. `web-version.json`, `service-worker.js` und Android-`build.gradle` auf v0.74 gesetzt.

## Prüfstand
- JavaScript-Syntaxprüfungen (Web, iOS-PWA und Android-Assets): OK.
- Synthetischer Test gemeinsamer Modellgewichtung sowie Windrichtungs-Mix 350°/10°: OK.
- Synthetischer Kartenraster-Vergleich mit vier Modellen: OK.
- Gleichzeitige Tube- und Softkite-Empfehlung: OK.
- Browser-End-to-End-Test ist in dieser Umgebung blockiert; Live-Server, GitHub-Build, Android-/iPhone-Performance und Alarmlaufzeit **noch nicht geprüft**.

## WICHTIG: Versions-/Sicherheitsbasis
Diese Demo-Dateien wurden auf der vorhandenen **ursprünglichen v0.73 Android/Web/iOS-Basis** erzeugt. Die neueren Sicherheitspakete **S1/S2/S3** und die spätere Startseiten-/Server-Aktualisierung **S4** waren in dieser Umgebung nicht vollständig als editierbare Quelldateien verfügbar.

**Deshalb das vollständige Demo-Verzeichnis NICHT auf den Live-Server hochladen und das Android-Projekt NICHT als öffentliches Update veröffentlichen.** Das könnte Sicherheitskorrekturen zurückrollen.

Für den echten Release die Datei `kb_v074_patch.py` auf eine **KOPIE der neuesten gesicherten Quellbasis** anwenden; anschließend die Unterschiede und Sicherheitskorrekturen prüfen, die Live-PHP-Alarmfunktion auditieren und alle Integrations- und Lasttests durchführen. Der Patch verändert keine Tokens oder Server-Konfigurationen und veröffentlicht nichts selbst.

Beispiel bei vorhandenem Python 3:

```
python kb_v074_patch.py /pfad/zur/kopie/web-beta /pfad/zur/kopie/android-app/app/src/main/assets
```

Die Android-App-Versionsnummer muss nach dem Patch im `app/build.gradle` separat auf `versionCode 74`, `versionName '0.74 Beta'` erhöht werden.

## Vor Release verifizieren
- Wulfen, 7.11. 12 Uhr: Marker und Forecast-Tabelle müssen den gleichen Windwert und dieselbe Richtung zeigen (einschließlich identischem Confidence / KiteScore bei gleichem Standort, Zeitpunkt und Datenstand).
- Windpfeile sind Superforecast-Kartenraster: räumliche Interpolation erlaubt lokale Unterschiede, aber kein DWD-Einzelmodellmix mehr.
- Bei nur einem verfügbaren Modell erscheint kein „Superforecast-Windfeld“.
- Auf- und Zuziehen der Karte, Stunden-Slider, neuer App-Start und Offline-/Cachefälle testen; insbesondere Anzahl Anfragen und Speicherverbrauch.
- Alarm-Soforttest und In-App-Alarm mit derselben Zeitreihe; Hintergrund-Push erst nach gesonderter Serverprüfung.
- Eigene Kites unterschiedlicher Art parallel eingeben, wechseln, löschen und im Forecast wiederfinden; über Gerätegrenzen ist die Materialliste derzeit **nicht synchronisiert**.
- Bestehende Daten, Favoriten, Lizenzen, Sicherheit und Login weiterhin funktionsfähig.
