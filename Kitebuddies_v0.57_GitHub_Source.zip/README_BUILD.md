# Kitebuddies Nord Forecast Pro v0.57 Beta – Statusleisten-Fix

Basis: funktionierende v0.56 Beta.

Änderungen in v0.57:
- VersionCode 57 / VersionName 0.57 Beta
- minSdk 24 / targetSdk 37 unverändert
- Nur der native obere Fensterbereich wurde korrigiert.
- Auf Android 15+ wird der gesamte WebView über einen Root-Container um die echte Statusleistenhöhe nach unten versetzt.
- Dadurch überlappen Uhrzeit/WLAN/Akku und der Kitebuddies-App-Header nicht mehr.
- Forecast, Karte, Modellvergleich, Update-Logik, Firebase, Push und Alarmregeln unverändert.
- Integrierte Anleitung auf v0.57 aktualisiert.
