Kitebuddies v0.77 Beta RC3 – gemeinsames Anzeige-Update (TEST)

- Android: Jeder empfangene Windalarm hat eine eigene Notification-ID und PendingIntent-ID.
- Android: Spotdateien erhalten beim Speichern oder Teilen einen frei wählbaren Dateinamen.
- Web/iOS: eingehende In-App-Alarme werden nacheinander angezeigt (Stammdatei).
- FCM-Versand, Alarmregeln, Forecast, Wetter-API, Tide und Spotformat unverändert.
- Signiert mit unverändertem bestehenden Android-Zertifikat per GitHub Actions.
- Nicht vor End-to-End-Tests an alle Beta-Tester veröffentlichen.
