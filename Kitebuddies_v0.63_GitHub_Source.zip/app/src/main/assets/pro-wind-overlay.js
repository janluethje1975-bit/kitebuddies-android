/* Kitebuddies Nord Forecast Pro v0.30 Beta
   Request-efficient wind field: one universal 8-day hourly package per viewport,
   persistent on-device cache, slider without network requests, server-managed rate limiting.
   DWD ICON via Kitebuddies Weather API. No animated particles. v0.26: Pfeile only; colored raster background removed for performance. */
(function(){
'use strict';
const PRO_WIND={
  enabled:false, canvas:null, ctx:null, panel:null, slider:null, timeLabel:null, status:null, pill:null,
  timeline:[], selectedTime:null, displayedTime:null, points:[], currentPackage:null,
  cache:new Map(), cacheOrder:[], maxCache:8, freshMs:3*3600000, staleMs:36*3600000,
  mapBound:false, fetchTimer:null, drawFrame:null, requestSeq:0, aborter:null, lastGrid:null,
  lastNetworkAttempt:0, minNetworkGapMs:5000,
  storagePrefix:'kb_pro_wind_pkg_v030_', storageIndex:'kb_pro_wind_pkg_index_v030',
  arrowSourceId:'kb-pro-wind-arrows-source', arrowLayerId:'kb-pro-wind-arrows-layer'
};
window.KBPro=window.KBPro||{};window.KBPro.windOverlay=PRO_WIND;
const hourMs=3600000;
const q=id=>document.getElementById(id);
function pClamp(v,a,b){return Math.max(a,Math.min(b,v))}
function localHour(t){try{const parts=new Intl.DateTimeFormat('en-GB',{timeZone:getTimezone(),hour:'2-digit',hourCycle:'h23'}).formatToParts(forecastDate(t));return Number(parts.find(x=>x.type==='hour')?.value)}catch(e){return forecastDate(t).getUTCHours()}}
function timeStepHours(){return state.periodFilter==='3days'?3:state.periodFilter==='7days'?6:1}
function makeTimeline(){const step=timeStepHours(),now=Date.now(),start=Math.floor((now-24*hourMs)/hourMs)*hourMs,end=now+8*24*hourMs,out=[];for(let ms=start;ms<=end;ms+=hourMs){const d=new Date(ms);if(!periodMatch(d,state.periodFilter))continue;if(step>1&&localHour(d)%step!==0)continue;out.push(d.toISOString())}return out}
function timeLong(t){return formatTZ(t,{weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'})+' Uhr'}
function timeShort(t){return formatTZ(t,{hour:'2-digit',minute:'2-digit'})}
function buildUI(){
  if(q('proWindOverlayBtn'))return;
  const windRange=q('mapWindThresholdBtn');if(!windRange)return;
  const btn=document.createElement('button');btn.className='filter-btn pro-wind-btn';btn.id='proWindOverlayBtn';btn.type='button';btn.textContent='Wind-Overlay';btn.setAttribute('aria-pressed','false');windRange.insertAdjacentElement('afterend',btn);
  const mapStage=q('mapStage'),mapCard=mapStage?.closest('.map-card'),below=mapCard?.querySelector('.map-below');if(!mapStage||!mapCard||!below)return;
  const canvas=document.createElement('canvas');canvas.id='proWindCanvas';canvas.setAttribute('aria-hidden','true');mapStage.appendChild(canvas);
  const pill=document.createElement('div');pill.id='proWindMapPill';pill.className='pro-wind-map-pill';mapStage.appendChild(pill);
  const legend=document.createElement('div');legend.id='proWindMapLegend';legend.className='pro-wind-map-legend';legend.setAttribute('aria-label','Windstärke in Knoten, Farben der Windrichtungspfeile');legend.innerHTML=`<div class="pro-wind-map-legend-label">Wind kn</div><div class="pro-wind-map-legend-body"><div class="pro-wind-map-legend-ticks"><span>45+</span><span>30</span><span>15</span><span>0</span></div><div class="pro-wind-map-legend-grad"></div></div><div class="pro-wind-map-legend-note">➤ Richtung</div>`;mapStage.appendChild(legend);
  const panel=document.createElement('div');panel.id='proWindPanel';panel.className='pro-wind-panel';panel.innerHTML=`
    <div class="pro-wind-head"><div class="pro-wind-title">Windfeld · Grundwind (10 m)</div><div class="pro-wind-head-right"><div id="proWindTimeLabel" class="pro-wind-time">–</div><details id="proWindInfoDetails" class="pro-wind-info"><summary title="Windfeld-Informationen" aria-label="Technische Windfeld-Informationen anzeigen">i</summary><div class="pro-wind-info-pop"><b>Windfeld · technische Informationen</b><p>Kitebuddies-Server · 1 Datenpaket je Kartenbereich · Zeitregler ohne neue Abfrage.</p><p id="proWindStatus" class="pro-wind-status" role="status">Windfeld aus</p><p class="pro-wind-source">Datenbasis: Deutscher Wetterdienst (DWD ICON) über Kitebuddies Weather API · Aufbereitung via Open-Meteo · CC BY 4.0. Modell-Forecast als Entscheidungshilfe, keine Sicherheitsgarantie.</p></div></details></div></div>
    <div class="pro-wind-slider-row"><input id="proWindTimeSlider" type="range" min="0" max="0" step="1" value="0" aria-label="Zeitpunkt des Windfelds"><div class="pro-wind-axis"><span id="proWindAxisStart">–</span><span id="proWindAxisStep">–</span><span id="proWindAxisEnd">–</span></div></div>`;
  mapCard.insertBefore(panel,below);
  PRO_WIND.canvas=canvas;PRO_WIND.ctx=canvas.getContext('2d');PRO_WIND.panel=panel;PRO_WIND.slider=q('proWindTimeSlider');PRO_WIND.timeLabel=q('proWindTimeLabel');PRO_WIND.status=q('proWindStatus');PRO_WIND.pill=pill;
  btn.addEventListener('click',()=>setEnabled(!PRO_WIND.enabled));
  PRO_WIND.slider.addEventListener('input',()=>{const i=Number(PRO_WIND.slider.value)||0;selectTimelineIndex(i)});
  PRO_WIND.slider.addEventListener('change',()=>{window.KBMapTimeChanged?.(PRO_WIND.selectedTime,true);displaySelected(true)});
  document.querySelectorAll('.period-btn').forEach(b=>b.addEventListener('click',()=>setTimeout(periodChanged,0)));
  window.addEventListener('resize',()=>{resizeCanvas();scheduleArrowDraw()},{passive:true});
  try{localStorage.removeItem('kb_pro_wind_backoff_v09');localStorage.removeItem('kb_om_global_backoff_v1');localStorage.removeItem('kb_pro_wind_pkg_index_v012');localStorage.removeItem('kb_pro_wind_pkg_index_v013');localStorage.removeItem('kb_pro_wind_pkg_index_v014');localStorage.removeItem('kb_pro_wind_pkg_index_v015')}catch(e){}
  loadPersistentIndex();
  try{if(localStorage.getItem('kb_pro_wind_overlay_enabled')==='1')setTimeout(()=>setEnabled(true),250)}catch(e){}
}
function setStatus(text,kind=''){if(!PRO_WIND.status)return;PRO_WIND.status.textContent=text;PRO_WIND.status.className='pro-wind-status'+(kind?' '+kind:'')}
function setEnabled(on){
  PRO_WIND.enabled=!!on;const btn=q('proWindOverlayBtn');btn?.classList.toggle('active',PRO_WIND.enabled);btn?.setAttribute('aria-pressed',PRO_WIND.enabled?'true':'false');PRO_WIND.panel?.classList.toggle('show',PRO_WIND.enabled);PRO_WIND.canvas?.classList.remove('active');PRO_WIND.pill?.classList.toggle('show',PRO_WIND.enabled);q('proWindMapLegend')?.classList.toggle('show',PRO_WIND.enabled);if(!PRO_WIND.enabled&&q('proWindInfoDetails'))q('proWindInfoDetails').open=false;
  try{localStorage.setItem('kb_pro_wind_overlay_enabled',PRO_WIND.enabled?'1':'0')}catch(e){}
  if(!PRO_WIND.enabled){if(PRO_WIND.aborter)PRO_WIND.aborter.abort();clearArrowCanvas();setArrowVisible(false);setStatus('Windfeld aus');return}
  rebuildTimeline(true);bindMapWhenReady();setArrowVisible(true);
}
function rebuildTimeline(preserve){
  const prev=preserve?PRO_WIND.selectedTime:null;PRO_WIND.timeline=makeTimeline();PRO_WIND.slider.max=Math.max(0,PRO_WIND.timeline.length-1);let idx=0;
  if(prev&&PRO_WIND.timeline.length){let best=Infinity;PRO_WIND.timeline.forEach((t,i)=>{const d=Math.abs(forecastDate(t)-forecastDate(prev));if(d<best){best=d;idx=i}})}
  PRO_WIND.slider.value=String(idx);q('proWindAxisStart').textContent=PRO_WIND.timeline.length?timeShort(PRO_WIND.timeline[0]):'–';q('proWindAxisEnd').textContent=PRO_WIND.timeline.length?timeShort(PRO_WIND.timeline[PRO_WIND.timeline.length-1]):'–';q('proWindAxisStep').textContent=`${timeStepHours()} h Schritte · ${periodLabel(state.periodFilter)}`;
  if(PRO_WIND.timeline.length){const ready=selectTimelineIndex(idx);if(!ready)queuePackageFetch(40)}else{PRO_WIND.selectedTime=null;PRO_WIND.timeLabel.textContent='Kein Zeitpunkt';PRO_WIND.pill.textContent='Kein Windfeld';setStatus('Für den gewählten Zeitraum ist kein weiterer Zeitschritt verfügbar.','error');clearArrowCanvas()}
}
function periodChanged(){if(!PRO_WIND.enabled)return;rebuildTimeline(false)}
function selectTimelineIndex(i){if(!PRO_WIND.timeline.length)return false;i=pClamp(i,0,PRO_WIND.timeline.length-1);PRO_WIND.slider.value=String(i);PRO_WIND.selectedTime=PRO_WIND.timeline[i];PRO_WIND.timeLabel.textContent=timeLong(PRO_WIND.selectedTime);PRO_WIND.pill.textContent=`Grundwind · ${timeLong(PRO_WIND.selectedTime)}`;window.KBMapTimeChanged?.(PRO_WIND.selectedTime,false);return displaySelected(false)}
function bindMapWhenReady(){if(!PRO_WIND.enabled)return;if(typeof state!=='undefined'&&state.map){bindMap();queuePackageFetch(0);return}setStatus('Online-Karte lädt …','loading');setTimeout(bindMapWhenReady,350)}
function bindMap(){
  if(PRO_WIND.mapBound||!state.map)return;
  PRO_WIND.mapBound=true;
  resizeCanvas();
  let mapEndTimer=null,mapBusyId=null;
  const finishMapBusy=()=>{if(mapBusyId){window.KBBusy?.end?.(mapBusyId);mapBusyId=null}};
  const beginMapWork=()=>{setArrowVisible(false);clearTimeout(mapEndTimer);finishMapBusy()};
  const afterMapChange=(delay)=>{clearTimeout(mapEndTimer);finishMapBusy();mapBusyId=window.KBBusy?.begin?.('Kartenbereich wird aktualisiert','Windfeld · Kartenkacheln · Pfeile',500)||null;mapEndTimer=setTimeout(()=>{if(!PRO_WIND.enabled){finishMapBusy();return}if(packageCoversView(PRO_WIND.currentPackage)){renderArrowLayer();finishMapBusy()}else{finishMapBusy();queuePackageFetch(delay)}},650)};
  state.map.on('movestart',beginMapWork);
  state.map.on('zoomstart',beginMapWork);
  state.map.on('moveend',()=>afterMapChange(650));
  state.map.on('zoomend',()=>afterMapChange(650));
  state.map.on('resize',()=>{resizeCanvas();afterMapChange(700)});
}
function resizeCanvas(){const c=PRO_WIND.canvas,stage=q('mapStage');if(!c||!stage)return;const r=stage.getBoundingClientRect(),dpr=Math.min(window.devicePixelRatio||1,2),w=Math.max(1,Math.round(r.width*dpr)),h=Math.max(1,Math.round(r.height*dpr));if(c.width!==w||c.height!==h){c.width=w;c.height=h;c.style.width=r.width+'px';c.style.height=r.height+'px';PRO_WIND.ctx?.setTransform(dpr,0,0,dpr,0,0)}}
function clearArrowCanvas(){if(PRO_WIND.ctx&&PRO_WIND.canvas){const r=PRO_WIND.canvas.getBoundingClientRect();PRO_WIND.ctx.clearRect(0,0,r.width,r.height)}setArrowVisible(false)}
function scheduleArrowDraw(){if(!PRO_WIND.enabled||PRO_WIND.drawFrame)return;PRO_WIND.drawFrame=requestAnimationFrame(()=>{PRO_WIND.drawFrame=null;renderArrowLayer()})}

function bilinear(a,b,c,d,tx,ty){const top=a+(b-a)*tx,bottom=d+(c-d)*tx;return top+(bottom-top)*ty}
function sampleWindAt(normX,normY){const g=PRO_WIND.lastGrid,pts=PRO_WIND.points;if(!g||!pts.length||g.cols<2||g.rows<2)return null;const cols=g.cols,rows=g.rows,gx=pClamp(normX,0,1)*(cols-1),gy=pClamp(normY,0,1)*(rows-1),ix=Math.min(cols-2,Math.floor(gx)),iy=Math.min(rows-2,Math.floor(gy)),tx=gx-ix,ty=gy-iy,i=iy*cols+ix,p00=pts[i],p10=pts[i+1],p11=pts[i+cols+1],p01=pts[i+cols];if(!p00||!p10||!p11||!p01)return null;const wind=bilinear(p00.wind,p10.wind,p11.wind,p01.wind,tx,ty),dir=bilinearDir(p00.dir,p10.dir,p11.dir,p01.dir,tx,ty),lon=g.west+(g.east-g.west)*pClamp(normX,0,1),lat=g.north-(g.north-g.south)*pClamp(normY,0,1);return{wind,dir,lon,lat}}
function sampleWindAtLonLat(lon,lat){const g=PRO_WIND.lastGrid;if(!g||!Number.isFinite(lon)||!Number.isFinite(lat)||g.east===g.west||g.north===g.south)return null;const nx=(lon-g.west)/(g.east-g.west),ny=(g.north-lat)/(g.north-g.south);if(nx<-.03||nx>1.03||ny<-.03||ny>1.03)return null;return sampleWindAt(nx,ny)}
PRO_WIND.sampleAtSpot=function(lon,lat,targetTime){if(!PRO_WIND.enabled||!PRO_WIND.displayedTime)return null;const tm=targetTime?forecastDate(targetTime).getTime():forecastDate(PRO_WIND.selectedTime).getTime(),dm=forecastDate(PRO_WIND.displayedTime).getTime();if(!Number.isFinite(tm)||!Number.isFinite(dm)||Math.abs(tm-dm)>45*60000)return null;const p=sampleWindAtLonLat(Number(lon),Number(lat));return p?{...p,time:PRO_WIND.displayedTime,source:'DWD ICON'}:null};
function bilinearDir(a,b,c,d,tx,ty){const r=Math.PI/180,vec=x=>({x:Math.cos(x*r),y:Math.sin(x*r)}),va=vec(a),vb=vec(b),vc=vec(c),vd=vec(d),x=bilinear(va.x,vb.x,vc.x,vd.x,tx,ty),y=bilinear(va.y,vb.y,vc.y,vd.y,tx,ty);return((Math.atan2(y,x)/r)%360+360)%360}
function firstSymbolLayerId(){try{return state.map.getStyle()?.layers?.find(l=>l.type==='symbol')?.id}catch(e){return undefined}}

/* v0.17: MapLibre symbol arrows retained from v0.16; Shore filter added separately. */
const ARROW_COLORS=['#176cff','#00cfff','#00e2c0','#20e85f','#ffe000','#ff9a00','#ff571f','#f42126','#d0008f','#9026db'];
function arrowBucket(kn){const v=Number(kn)||0;return v<7?0:v<11?1:v<15?2:v<20?3:v<25?4:v<30?5:v<35?6:v<41?7:v<49?8:9}
function arrowImageData(color){const can=document.createElement('canvas');can.width=48;can.height=48;const c=can.getContext('2d');c.clearRect(0,0,48,48);c.lineCap='round';c.lineJoin='round';/* v0.17: v0.16 slim arrow geometry retained; only a hairline dark outline (~0.25 px/side at pixelRatio 2). */c.strokeStyle='rgba(2,10,15,.78)';c.lineWidth=4.2;c.beginPath();c.moveTo(24,40);c.lineTo(24,13.5);c.stroke();c.fillStyle='rgba(2,10,15,.78)';c.beginPath();c.moveTo(24,5.4);c.lineTo(16.3,17.5);c.lineTo(31.7,17.5);c.closePath();c.fill();c.strokeStyle=color;c.lineWidth=3.2;c.beginPath();c.moveTo(24,39.4);c.lineTo(24,14.1);c.stroke();c.fillStyle=color;c.beginPath();c.moveTo(24,7.0);c.lineTo(17.7,16.8);c.lineTo(30.3,16.8);c.closePath();c.fill();return c.getImageData(0,0,48,48)}
function ensureArrowImages(m){for(let i=0;i<ARROW_COLORS.length;i++){const id=`kb-wind-arrow-${i}`;try{if(!m.hasImage?.(id))m.addImage(id,arrowImageData(ARROW_COLORS[i]),{pixelRatio:2})}catch(e){console.warn('Pro Wind arrow image',id,e)}}}
function ensureArrowLayer(){const m=state.map;if(!m||!m.isStyleLoaded?.())return false;try{ensureArrowImages(m);if(!m.getSource(PRO_WIND.arrowSourceId))m.addSource(PRO_WIND.arrowSourceId,{type:'geojson',data:{type:'FeatureCollection',features:[]}});if(!m.getLayer(PRO_WIND.arrowLayerId)){const before=firstSymbolLayerId();m.addLayer({id:PRO_WIND.arrowLayerId,type:'symbol',source:PRO_WIND.arrowSourceId,layout:{'icon-image':['get','icon'],'icon-rotate':['get','rotation'],'icon-rotation-alignment':'map','icon-pitch-alignment':'map','icon-size':0.76,'icon-allow-overlap':true,'icon-ignore-placement':true,'visibility':'visible'},paint:{'icon-opacity':0.96}},before)}return true}catch(e){console.warn('Pro Wind arrow layer',e);return false}}
function setArrowVisible(on){const m=typeof state!=='undefined'?state.map:null;if(!m)return;try{if(m.getLayer(PRO_WIND.arrowLayerId))m.setLayoutProperty(PRO_WIND.arrowLayerId,'visibility',on?'visible':'none')}catch(e){}}
function arrowDisplayGrid(rect,z){let spacing,maxArrows,size;if(z<5.6){spacing=60;maxArrows=130;size=.62}else if(z<6.6){spacing=52;maxArrows=170;size=.68}else if(z<7.6){spacing=45;maxArrows=215;size=.74}else if(z<8.8){spacing=39;maxArrows=265;size=.82}else{spacing=33;maxArrows=330;size=.90}let cols=pClamp(Math.ceil(rect.width/spacing),5,26),rows=pClamp(Math.ceil(rect.height/spacing),4,30);while(cols*rows>maxArrows){if(cols/Math.max(rows,1)>rect.width/Math.max(rect.height,1)&&cols>5)cols--;else if(rows>4)rows--;else if(cols>5)cols--;else break}return{cols,rows,size}}
function renderArrowLayer(){if(!PRO_WIND.enabled||!state.map||!PRO_WIND.points.length||!PRO_WIND.lastGrid){setArrowVisible(false);return}if(!ensureArrowLayer())return;const m=state.map,rect=m.getCanvas?.().getBoundingClientRect?.()||q('mapStage')?.getBoundingClientRect();if(!rect||rect.width<20||rect.height<20)return;const z=m.getZoom?.()||6,grid=arrowDisplayGrid(rect,z),features=[];for(let row=0;row<grid.rows;row++){const y=(row+.5)*rect.height/grid.rows;for(let col=0;col<grid.cols;col++){const x=(col+.5)*rect.width/grid.cols,ll=m.unproject([x,y]),p=sampleWindAtLonLat(ll.lng,ll.lat);if(!p||!Number.isFinite(p.wind)||!Number.isFinite(p.dir))continue;features.push({type:'Feature',properties:{icon:`kb-wind-arrow-${arrowBucket(p.wind)}`,rotation:((p.dir+180)%360+360)%360,wind:+p.wind.toFixed(1)},geometry:{type:'Point',coordinates:[ll.lng,ll.lat]}})}}try{m.getSource(PRO_WIND.arrowSourceId)?.setData({type:'FeatureCollection',features});m.setLayoutProperty(PRO_WIND.arrowLayerId,'icon-size',grid.size);setArrowVisible(true)}catch(e){console.warn('Pro Wind arrows update',e)}}

function gridSpec(){if(!state.map)return null;const z=state.map.getZoom?.()||6,b=state.map.getBounds();let west=b.getWest(),east=b.getEast(),south=b.getSouth(),north=b.getNorth();const lonSpan=Math.max(.01,east-west),latSpan=Math.max(.01,north-south),lonPad=lonSpan*.24,latPad=latSpan*.24;west-=lonPad;east+=lonPad;south=pClamp(south-latPad,-85,85);north=pClamp(north+latPad,-85,85);if(north<=south){north=pClamp(south+.1,-85,85)}let cols,rows;if(z<5.6){cols=5;rows=4}else if(z<6.8){cols=6;rows=5}else if(z<8.2){cols=7;rows=6}else if(z<9.6){cols=8;rows=7}else{cols=9;rows=7}const pts=[];for(let y=0;y<rows;y++){const fy=y/(rows-1),lat=north-(north-south)*fy;for(let x=0;x<cols;x++){const fx=x/(cols-1),lon=west+(east-west)*fx;pts.push({lat:+pClamp(lat,-85,85).toFixed(5),lon:+lon.toFixed(5)})}}const center=state.map.getCenter(),band=z<5.6?'w':z<6.8?'m':z<8.2?'n':z<9.6?'c':'x',snap=band==='w'?1.2:band==='m'?.55:band==='n'?.22:band==='c'?.10:.05,sig=`${band}|${Math.round(center.lat/snap)*snap}|${Math.round(center.lng/snap)*snap}|${cols}x${rows}`;return{points:pts,cols,rows,sig,west,east,south,north,zoomBand:band}}
function packageCoversView(pkg){if(!pkg||!state.map)return false;const b=state.map.getBounds(),g=pkg.grid;return b.getWest()>=g.west&&b.getEast()<=g.east&&b.getSouth()>=g.south&&b.getNorth()<=g.north&&timeCovered(pkg,PRO_WIND.selectedTime)}
function timeCovered(pkg,t){if(!pkg||!t||!pkg.times?.length)return false;const ms=forecastDate(t).getTime();return ms>=pkg.startMs-1800000&&ms<=pkg.endMs+1800000}
function queuePackageFetch(delay=400){if(!PRO_WIND.enabled||!PRO_WIND.selectedTime)return;clearTimeout(PRO_WIND.fetchTimer);PRO_WIND.fetchTimer=setTimeout(ensurePackage,delay)}
function packageKey(grid){return `${grid.sig}|8d-hourly-v030`}
function memorySet(pkg){PRO_WIND.cache.set(pkg.key,pkg);PRO_WIND.cacheOrder=PRO_WIND.cacheOrder.filter(k=>k!==pkg.key);PRO_WIND.cacheOrder.push(pkg.key);while(PRO_WIND.cacheOrder.length>PRO_WIND.maxCache){const k=PRO_WIND.cacheOrder.shift();PRO_WIND.cache.delete(k)}}
function loadPersistentIndex(){try{const idx=JSON.parse(localStorage.getItem(PRO_WIND.storageIndex)||'[]');if(!Array.isArray(idx))return;for(const ent of idx.slice(-PRO_WIND.maxCache)){try{const raw=localStorage.getItem(PRO_WIND.storagePrefix+ent.key);if(!raw)continue;const pkg=JSON.parse(raw);if(pkg?.key&&pkg?.grid&&pkg?.times)memorySet(pkg)}catch(e){}}}catch(e){}}
function savePersistent(pkg){try{localStorage.setItem(PRO_WIND.storagePrefix+pkg.key,JSON.stringify(pkg));let idx=JSON.parse(localStorage.getItem(PRO_WIND.storageIndex)||'[]');if(!Array.isArray(idx))idx=[];idx=idx.filter(x=>x.key!==pkg.key);idx.push({key:pkg.key,savedAt:pkg.savedAt});while(idx.length>PRO_WIND.maxCache){const old=idx.shift();try{localStorage.removeItem(PRO_WIND.storagePrefix+old.key)}catch(e){}}localStorage.setItem(PRO_WIND.storageIndex,JSON.stringify(idx))}catch(e){console.warn('Wind cache save',e)}}
function findCached(grid,allowStale=false){const now=Date.now();let best=null;for(const pkg of PRO_WIND.cache.values()){if(!timeCovered(pkg,PRO_WIND.selectedTime))continue;const b=state.map.getBounds(),g=pkg.grid;if(!(b.getWest()>=g.west&&b.getEast()<=g.east&&b.getSouth()>=g.south&&b.getNorth()<=g.north))continue;const age=now-(pkg.savedAt||0);if(age<=(allowStale?PRO_WIND.staleMs:PRO_WIND.freshMs)){if(!best||pkg.savedAt>best.savedAt)best=pkg}}return best}
function nearestTimeIndex(pkg,t){const target=forecastDate(t).getTime();let bi=0,bd=Infinity;(pkg.times||[]).forEach((tm,i)=>{const d=Math.abs(forecastDate(tm).getTime()-target);if(d<bd){bd=d;bi=i}});return bi}
function displayPackage(pkg,cacheLabel=''){if(!pkg)return false;const ti=nearestTimeIndex(pkg,PRO_WIND.selectedTime),winds=pkg.winds?.[ti],dirs=pkg.dirs?.[ti];if(!winds||!dirs||winds.length!==pkg.grid.points.length)return false;PRO_WIND.currentPackage=pkg;PRO_WIND.lastGrid=pkg.grid;PRO_WIND.displayedTime=pkg.times?.[ti]||PRO_WIND.selectedTime;PRO_WIND.points=pkg.grid.points.map((p,i)=>({...p,wind:Number(winds[i]),dir:Number(dirs[i])}));renderArrowLayer();const age=Math.max(0,Date.now()-(pkg.savedAt||Date.now()));const ageText=age>6*3600000?` · ${Math.round(age/3600000)} h alt`:'';setStatus(`Grundwind · DWD ICON · ${PRO_WIND.points.length} Rasterpunkte${pkg.serverSource?` · ${pkg.serverSource==='open_meteo_live'?'Server neu':pkg.serverSource==='cache_fresh'?'Server-Cache':pkg.serverSource==='cache_stale'?'Server älterer Cache':'Server'}`:''}${cacheLabel?` · ${cacheLabel}${ageText}`:''}`);window.KBMapWindFieldChanged?.(PRO_WIND.displayedTime);return true}
function displaySelected(allowQueue=true){if(PRO_WIND.currentPackage&&timeCovered(PRO_WIND.currentPackage,PRO_WIND.selectedTime)){displayPackage(PRO_WIND.currentPackage,'Cache');return true}const cached=findCached(gridSpec(),true);if(cached){displayPackage(cached,'Cache');return true}if(allowQueue)queuePackageFetch(300);return false}
function apiHour(t){return new Date(forecastDate(t)).toISOString().slice(0,13)+':00'}
async function requestPackage(grid,signal){
  const lats=grid.points.map(p=>p.lat).join(','),lons=grid.points.map(p=>p.lon).join(','),params=new URLSearchParams({action:'model',model:'dwd',latitude:lats,longitude:lons,hourly:'wind_speed_10m,wind_direction_10m',forecast_days:'8',timezone:'UTC',cell_selection:'nearest',token:'c33f71d0b84e3afc8509cbeff496f37f4b1cdd097e1c3d94'}),url='https://api.kitebuddies-nord.de/kb-weather-api.php?'+params;
  const res=await fetch(url,{signal,cache:'no-store'});let env=null;try{env=await res.json()}catch(e){}if(!res.ok||env?.ok===false){const reason=env?.upstream_reason||env?.upstream_error||env?.error||('HTTP '+res.status);throw new Error(reason)}
  const raw=env?.data,serverSource=env?.source||'server';const list=Array.isArray(raw)?raw:[raw];if(list.length!==grid.points.length)throw new Error('Unvollständige Rasterdaten');
  const times=(list[0]?.hourly?.time||[]).map(t=>new Date(forecastDate(t)).toISOString());if(!times.length)throw new Error('Keine Zeitachse im Windpaket');
  const winds=times.map(()=>new Array(grid.points.length)),dirs=times.map(()=>new Array(grid.points.length));
  list.forEach((item,pi)=>{const h=item?.hourly,sourceTimes=h?.time||[],ws=h?.wind_speed_10m||[],ds=h?.wind_direction_10m||[];const direct=sourceTimes.length===times.length&&sourceTimes.every((t,j)=>Math.abs(forecastDate(t).getTime()-forecastDate(times[j]).getTime())<60000);for(let ti=0;ti<times.length;ti++){let bi=ti;if(!direct){const targetMs=forecastDate(times[ti]).getTime();let bd=Infinity;for(let j=0;j<sourceTimes.length;j++){const d=Math.abs(forecastDate(sourceTimes[j]).getTime()-targetMs);if(d<bd){bd=d;bi=j}}}winds[ti][pi]=Number(ws[bi]);dirs[ti][pi]=Number(ds[bi])}});
  if(winds.some(row=>row.some(v=>!Number.isFinite(v)))||dirs.some(row=>row.some(v=>!Number.isFinite(v))))throw new Error('Unvollständige Rasterdaten');
  return{key:packageKey(grid),grid,times,winds,dirs,startMs:forecastDate(times[0]).getTime(),endMs:forecastDate(times[times.length-1]).getTime(),savedAt:env?.saved_at_utc?forecastDate(env.saved_at_utc).getTime():Date.now(),source:'DWD ICON / Kitebuddies API',serverSource,packageVersion:30}
}
async function ensurePackage(){
  if(!PRO_WIND.enabled||!state.map||!PRO_WIND.selectedTime||!PRO_WIND.timeline.length)return;
  if(packageCoversView(PRO_WIND.currentPackage)){displayPackage(PRO_WIND.currentPackage,'Cache');return}
  const grid=gridSpec();if(!grid)return;const fresh=findCached(grid,false);if(fresh){displayPackage(fresh,'Cache');return}
  const stale=findCached(grid,true);if(stale)displayPackage(stale,'Cache');
  const now=Date.now();
  if(now-PRO_WIND.lastNetworkAttempt<PRO_WIND.minNetworkGapMs){queuePackageFetch(PRO_WIND.minNetworkGapMs-(now-PRO_WIND.lastNetworkAttempt)+100);return}
  const seq=++PRO_WIND.requestSeq;if(PRO_WIND.aborter)PRO_WIND.aborter.abort();const ac=new AbortController();PRO_WIND.aborter=ac;PRO_WIND.lastNetworkAttempt=now;setStatus(`Kitebuddies-Server lädt DWD-Windpaket · ${grid.points.length} Rasterpunkte · 8 Tage stündlich …`,'loading');const timeout=setTimeout(()=>ac.abort(),15000),busyId=window.KBBusy?.begin?.('Windfeld wird vorbereitet','8-Tage-Cache für den Kartenbereich',500)||null;
  try{const pkg=await requestPackage(grid,ac.signal);if(seq!==PRO_WIND.requestSeq||!PRO_WIND.enabled)return;memorySet(pkg);savePersistent(pkg);displayPackage(pkg,'neu geladen')}
  catch(e){if(e?.name==='AbortError'&&seq!==PRO_WIND.requestSeq)return;const msg=String(e?.message||'').slice(0,100);console.warn('Pro Wind Overlay',e);const fallback=findCached(grid,true);if(fallback){displayPackage(fallback,'Cache');setStatus(`Kitebuddies-Server momentan nicht erreichbar · gespeichertes Windfeld${Date.now()-fallback.savedAt>6*3600000?' · älterer Cache':''}`,'error')}else if(seq===PRO_WIND.requestSeq)setStatus(`Windfeld nicht geladen · Kitebuddies-Server · ${msg||'keine Daten'}`,'error')}
  finally{clearTimeout(timeout);if(PRO_WIND.aborter===ac)PRO_WIND.aborter=null;if(busyId)window.KBBusy?.end?.(busyId)}
}
function init(){try{buildUI();bindMapWhenReady()}catch(e){console.warn('Kitebuddies Pro Wind Overlay init',e)}}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else setTimeout(init,0);
})();
