/* Kitebuddies Nord Forecast v0.69: shared region/model policy.
 * Free and Pro use the same model-selection layer. Pro-only thermics is not yet enabled.
 */
(function(){
'use strict';
const dict={
 dwd_icon_seamless:{key:'dwd_icon_seamless',server:'dwd',name:'DWD / ICON',short:'ICON',color:'#35d9f5'},
 dmi_seamless:{key:'dmi_seamless',server:'dmi',name:'DMI / HARMONIE',short:'DMI',color:'#ffd34f'},
 ecmwf_ifs025:{key:'ecmwf_ifs025',server:'ecmwf',name:'ECMWF / IFS',short:'ECMWF',color:'#4e9cff'},
 gfs_seamless:{key:'gfs_seamless',server:'gfs',name:'NOAA / GFS',short:'GFS',color:'#ff5b8d'},
 ukmo_global:{key:'ukmo_global',server:'ukmo',name:'UK Met Office / Global',short:'UKMO',color:'#a77bff'},
 gem_global:{key:'gem_global',server:'gem',name:'CMC / GEM Global',short:'GEM',color:'#72d58a'}
};
const ids={
 nordic:['dwd_icon_seamless','dmi_seamless','ecmwf_ifs025','gfs_seamless'],
 europe:['dwd_icon_seamless','ecmwf_ifs025','gfs_seamless'],
 capetown:['ecmwf_ifs025','gfs_seamless','dwd_icon_seamless','ukmo_global','gem_global'],
 southern_africa:['ecmwf_ifs025','gfs_seamless','dwd_icon_seamless','ukmo_global','gem_global'],
 north_america:['gfs_seamless','ecmwf_ifs025','dwd_icon_seamless','gem_global','ukmo_global'],
 global:['ecmwf_ifs025','gfs_seamless','dwd_icon_seamless','ukmo_global','gem_global']
};
function region(lat,lon){
 const a=Number(lat),b=Number(lon);
 if(!Number.isFinite(a)||!Number.isFinite(b))return 'global';
 if(a>=-35.8&&a<=-32.5&&b>=16.0&&b<=20.8)return 'capetown';
 if(a>=-36.0&&a<=-21.0&&b>=15&&b<=36)return 'southern_africa';
 if(a>=53.0&&a<=72.0&&b>=4.5&&b<=33.0)return 'nordic';
 if(a>=35.0&&a<=72.0&&b>=-15.0&&b<=40.0)return 'europe';
 if(a>=7&&a<=75&&b>=-168&&b<=-52)return 'north_america';
 return 'global';
}
const labels={nordic:'Nord- und Ostsee / Nordeuropa',europe:'Europa',capetown:'Kapstadt / Westkap',southern_africa:'Südliches Afrika',north_america:'Nordamerika',global:'Weltweit'};
const tz={capetown:'Africa/Johannesburg',southern_africa:'Africa/Johannesburg',nordic:'Europe/Berlin',europe:'Europe/Berlin',north_america:'America/New_York',global:'UTC'};
function select(lat,lon,serverModels=[]){
 const id=region(lat,lon),enabled=new Set(serverModels||[]);
 const models=ids[id].filter(k=>!['ukmo_global','gem_global'].includes(k)||enabled.has(dict[k].server)).map(k=>({...dict[k]}));
 return {region:id,label:labels[id],defaultTimezone:tz[id],models,extended:models.some(m=>m.server==='ukmo'||m.server==='gem')};
}
function weight(modelKey,regionKey,hoursAhead){
 const h=Math.max(0,Number(hoursAhead)||0);
 if(modelKey==='dmi_seamless')return regionKey==='nordic'&&h<=60?1.3:0; // Avoid DMI seamless/ECMWF double counting on longer horizons
 if(modelKey==='dwd_icon_seamless')return regionKey==='nordic'||regionKey==='europe'?(h<=72?1.35:h<=120?1.12:.9):.90;
 if(modelKey==='ecmwf_ifs025')return 1.20;
 if(modelKey==='gfs_seamless')return regionKey==='north_america'?1.16:1.0;
 if(modelKey==='ukmo_global')return regionKey==='capetown'||regionKey==='southern_africa'?1.10:1.0;
 if(modelKey==='gem_global')return regionKey==='north_america'?1.10:.95;
 return 0;
}
window.KBRegionalModels={VERSION:'0.69',region,select,weight,labels,all:dict,THERMICS_PRO_ONLY:true};
})();
