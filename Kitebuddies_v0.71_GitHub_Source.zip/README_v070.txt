Kitebuddies v0.70: Thermik PRO, Cape-Doctor-Profil, keine KiteScore-Änderung. Siehe Begleit-Hinweise.
