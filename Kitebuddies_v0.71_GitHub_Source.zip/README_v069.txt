Kitebuddies Nord Forecast Pro v0.69 Beta

Android: versionCode 69 / versionName 0.69 Beta; Paketname unverändert.
Globales Regionenmodell mit serverseitig nachrüstbarem UKMO/GEM.
Wetter-API-Add-on kb-models-v069.php separat installieren (keine Ersetzung der bestehenden kb-weather-api.php).
Thermik bleibt PRO_ONLY-Platzhalter und greift noch nicht in KiteScore ein.
GitHub Actions muss die APK signieren; dieses ZIP ist kein APK-Download.
