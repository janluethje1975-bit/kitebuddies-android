Kitebuddies Nord Forecast Pro v0.68 Beta – Wind-Overlay AUS bei jedem neuen Start
==================================================================================
Basis: erfolgreich gebautes Android-v0.67-Quellpaket (Paket de.kitebuddies.forecast.prc).
VersionCode 68, VersionName 0.68 Beta.

Änderung:
- Wind-Overlay wird bei jedem neuen App-Start ausdrücklich abgeschaltet, auch wenn es vorher EIN war.
- Erst Tippen auf Wind-Overlay aktiviert Pfeile, Legende und Zeitregler.
- Zweites Tippen deaktiviert. Raster-Cache, Pfeilrichtung, Windmodelle, Shore-Anzeige, Marker, Favoriten, Alarme und Lizenz bleiben unangetastet.
- Bei Rückkehr aus dem Hintergrund innerhalb einer laufenden Sitzung bleibt ein manuell aktiviertes Overlay aktiv.
- Bei Wiederherstellung einer Seite aus dem Browser-Verlauf wird das Overlay ebenfalls ausgeschaltet.
- Interaktive Anleitung und Update-Manifest enthalten die Änderung.

Tests: siehe ../Dokumentation/TESTPROTOKOLL_v0.68.md.
Signierte APK: über GitHub-Actions-Workflow build-v068.yml; nicht aus dem Quell-ZIP direkt installierbar.
