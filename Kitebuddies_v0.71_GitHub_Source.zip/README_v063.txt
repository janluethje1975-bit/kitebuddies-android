KITEBUDDIES NORD FORECAST PRO v0.63 BETA
Basis: v0.62 Beta (keine Änderungen an Wetterdaten, API, Karten, Filtern, Push, Lizenz oder Alarmen).

Android-Systemnavigation Fix:
- Android 15+ / Android 17: WebView erhält zum oberen Statusleisten-Abstand auch einen unteren Abstand gemäß WindowInsets.Type.navigationBars().
- Schwarzer Hintergrund separat hinter Android-Navigationstasten, App endet oberhalb der Systemleiste.
- Kein künstlicher CSS-Abstand und kein Verlust der vertikalen Scrollfunktion.
- v0.62 Bedienoberfläche, Slider und Windlegende vollständig beibehalten.

Build: GitHub workflow .github/workflows/build-v063.yml signiert APK weiterhin mit den bestehenden Repository-Secrets.
Das Update-Manifest erst nach Installationstest veröffentlichen.
