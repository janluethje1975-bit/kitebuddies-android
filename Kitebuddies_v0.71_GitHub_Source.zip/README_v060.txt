KITEBUDDIES NORD FORECAST PRO – v0.60 BETA (TESTPAKETE)
============================================================

Gleiches Bedienkonzept für Android und Web/iOS. Basierend auf v0.59 Beta.

1. Im Alarmmenü stehen ausschließlich die mit ★ markierten Favoriten-Spots.
   Auch per Kartenauswahl sind nur diese Spots wählbar.
   Ohne Favoriten gibt es einen Hinweis; Speichern ist deaktiviert.
   Vorhandene ältere Alarmregeln für Nicht-Favoriten bleiben zur Sicherheit
   erhalten und lassen sich unter "Meine Alarme" ausdrücklich löschen.
2. Alarmeinstellungen wurden in aufklappbare Bereiche für Wind, Zeit,
   Windrichtung/Tide, Ton und technische Details geteilt.
3. Alarmglocke: leuchtet nur bei vorhandener gespeicherter, aktivierter
   Regel für den angezeigten Spot. Sonst ist sie durchgestrichen.
   Tippen öffnet die Alarm-Einstellungen.
4. Alarm-Löschen für den aktuellen Spot und jeden gespeicherten Alarm
   mit Sicherheitsbestätigung.
5. Beide Zeit-/Windfilterleisten sind kompakt und identisch; Zeitraum
   ist horizontal scrollbar, weitere Filter sind ausklappbar.
6. Graph-Detailpopup: per Tippen schließen; automatisch nach 20 Sekunden.
7. Tonwahl (sanft/klassisch/deutlich/stumm), Android-Firebase-Push und
   Web/iOS-In-App-Hinweise aus v0.59 bleiben bestehen.

ANDROID:
- Zuerst build-v060.yml als ".github/workflows/build-v060.yml" im
  GitHub-Repository anlegen. Dann Kitebuddies_v0.60_GitHub_Source.zip
  ins Repository hochladen und den Workflow starten.
- Für eine signierte Update-APK benötigt GitHub die bereits bekannte
  permanente Signing-Datei als Secret KB_KEYSTORE_B64 und das Passwort
  als KB_KEYSTORE_PASSWORD. Diese Secrets gehören NICHT in öffentliche Dateien.
- Nach erfolgreichem Build: neues Artifact herunterladen, die signierte
  APK installieren und gezielt auf Testgerät prüfen; den Server-Update-
  Manifest erst nach erfolgreicher Prüfung aktualisieren.

WEB/iOS:
- Nur den Ordner web-beta/ aus Kitebuddies_Web_iOS_v0.60_Beta_Upload.zip
  in die bestehende Webinstallation kopieren; nicht user-/Lizenzdaten ersetzen.
- web-version.json als letzte Datei hochladen, damit die neue Version
  erst sichtbar wird, wenn alle anderen Dateien bereitstehen.
- Web/iOS-Alarme arbeiten bei aktiver, geöffneter Anwendung. Keine
  Hintergrundbenachrichtigung bei geschlossener oder pausierter PWA.

GEPRÜFT:
- Gleicher Favoriten-Filter auf Android- und Web-Quellcode; Browser-
  Funktionstest für 2 Favoriten, Nicht-Favoriten und leere Favoritenliste.
- JavaScript-Syntax und DOM-IDs statisch geprüft.
- Kein vollständiger nativer Android-Build und kein Live-iOS-/Server-Test.
