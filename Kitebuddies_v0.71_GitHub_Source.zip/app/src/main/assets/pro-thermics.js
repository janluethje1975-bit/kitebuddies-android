/* Kitebuddies v0.70 Beta — Pro-only regional local-wind potential.
   Descriptive heuristics ONLY: no additions to wind, gusts, KiteScore, or warnings.
   Cape Doctor is predominantly synoptic south-easterly flow, not pure sea-breeze thermics.
*/
(function(){
'use strict';
const finite=x=>x===null||x===undefined||x===''?null:(Number.isFinite(Number(x))?Number(x):null);
const angle=(a,b)=>Math.abs(((a-b+540)%360)-180);
const capetown=(lat,lon)=>Number(lat)>=-35.8&&Number(lat)<=-32.5&&Number(lon)>=16&&Number(lon)<=20.8;
function sample(data,time){
 const points=Array.isArray(data)?data:(Array.isArray(data?.data)?data.data:(Array.isArray(data?.points)?data.points:null));
 const first=points?.[0]||data?.data||data, h=first?.hourly;
 if(!h||!Array.isArray(h.time)||!h.time.length)return null;
 const lookup=String(time||'').slice(0,16),i=h.time.findIndex(v=>String(v).slice(0,16)===lookup);
 if(i<0)return null; // Never substitute the wrong hour silently
 const value=(site,name)=>{const d=points?.[site]||(!site?first:null);return finite(d?.hourly?.[name]?.[i])};
 return {solar:value(0,'shortwave_radiation'),temperature:value(0,'temperature_2m'),cloud:value(0,'cloud_cover'),pressure:value(0,'pressure_msl'),pressureAtlantic:value(1,'pressure_msl'),pressureInterior:value(2,'pressure_msl'),wind:value(0,'wind_speed_10m'),direction:value(0,'wind_direction_10m'),source:data?.source||null,savedAt:data?.saved_at_utc||null};
}
function evaluate(ctx={}){
 const cape=capetown(ctx.lat,ctx.lon),t=new Date(/[zZ]$|[+\-]\d{2}:?\d{2}$/.test(String(ctx.time||''))?String(ctx.time):String(ctx.time||'')+'Z');
 const month=Number.isFinite(t.getTime())?t.getUTCMonth()+1:null;
 const summer=month!==null&&(month>=10||month<=4);
 const direction=finite(ctx.windDirection),wind=finite(ctx.wind),air=finite(ctx.airTemp),sea=finite(ctx.seaTemp),solar=finite(ctx.solar),cloud=finite(ctx.cloud);
 const atlantic=finite(ctx.pressureAtlantic),interior=finite(ctx.pressureInterior);
 const gradient=atlantic!==null&&interior!==null?atlantic-interior:null;
 const temperatureDifference=air!==null&&sea!==null?air-sea:null;
 const dataItems=[direction,wind,solar,cloud,temperatureDifference];
 const evidence=dataItems.filter(v=>v!==null).length+(cape&&gradient!==null?1:0);
 const maxEvidence=cape?6:5;
 const factors=[],cautions=[];
 if(!Number.isFinite(wind)||!Number.isFinite(direction))return{region:cape?'Cape Doctor / Westkap':'Seewind / Küste',level:'Unbestimmt',kind:'Keine Winddaten',description:'Für diesen Zeitpunkt fehlen echte Wind- oder Richtungswerte.',factors,confidence:`${evidence}/${maxEvidence} Datensignale`,gradient,temperatureDifference,source:ctx.source||'forecast'};
 let level='Gering',kind='Seewind-Thermik',description='Aktuell wenige Anzeichen für eine lokale thermische Windverstärkung.';
 if(cape){
  kind='Cape Doctor / Küstenverstärkung';
  const southeast=angle(direction,145)<=55;
  factors.push(southeast?'Südöstliche Strömung passt zum Cape-Doctor-Muster':'Windrichtung spricht derzeit nicht für eine typische Cape-Doctor-Lage');
  factors.push(summer?'Kapstadt-Sommersaison (Okt.–Apr.)':'Außerhalb der typischen Kapstadt-Sommersaison');
  if(gradient!==null)factors.push(`Druckdifferenz Atlantik − Inland: ${gradient>=0?'+':''}${gradient.toFixed(1)} hPa (grobe Referenzpunkte)`);
  if(solar!==null)factors.push(`Sonneneinstrahlung: ${Math.round(solar)} W/m²`);
  if(temperatureDifference!==null)factors.push(`Luft/Wasser-Kontrast: ${temperatureDifference>=0?'+':''}${temperatureDifference.toFixed(1)} °C`);
  const pressureSupport=gradient!==null&&gradient>=1.2;
  const strongSoutheaster=southeast&&wind>=14;
  if(summer&&strongSoutheaster&&(pressureSupport||wind>=20)){level='Hoch';description='Sommerliche Südostlage mit kräftigem Grundwind: großräumiger Cape Doctor und lokale Gelände-/Küsteneffekte sind möglich.'}
  else if(southeast&&(wind>=10||pressureSupport)){level='Mittel';description='Südöstliche Grundströmung: mögliche Verstärkung durch Cape-Halbinsel und Topografie; Druck- und Messdaten beachten.'}
  else{description='Derzeit keine ausgeprägte typische Cape-Doctor-Lage im Modell erkennbar.'}
  if(wind>=27)cautions.push('Bereits kräftiger Grundwind: starke Böen und lokale Düsen sind möglich. Keine Kite-Freigabe.');
  if(gradient===null)cautions.push('Druckgradient noch nicht verfügbar; Bewertung mit reduzierter Datenlage.');
 }else{
  const onshore=ctx.seaBearing!==null&&ctx.seaBearing!==undefined&&Number.isFinite(Number(ctx.seaBearing))&&angle(direction,Number(ctx.seaBearing))<=70;
  const radiationSupport=solar!==null&&solar>=350;
  const contrastSupport=temperatureDifference!==null&&temperatureDifference>=4;
  const weakWind=wind>=2&&wind<=14;
  if(temperatureDifference!==null)factors.push(`Luft/Wasser-Kontrast: ${temperatureDifference>=0?'+':''}${temperatureDifference.toFixed(1)} °C`);
  if(solar!==null)factors.push(`Sonneneinstrahlung: ${Math.round(solar)} W/m²`);
  if(cloud!==null)factors.push(`Bewölkung: ${Math.round(cloud)} %`);
  factors.push(weakWind?'Schwacher bis mäßiger großräumiger Wind':'Grundwind kann eine lokale Seewindzirkulation überlagern');
  factors.push(ctx.seaBearing!==null&&ctx.seaBearing!==undefined?(onshore?'Richtung passt zu Seewind von See':'Windrichtung passt nur eingeschränkt zu Seewind'):'Küstenorientierung unbekannt');
  if(onshore&&radiationSupport&&contrastSupport&&weakWind){level='Hoch';description='Sonne, Land-Meer-Temperaturunterschied, Grundwind und Richtung begünstigen Seewind.'}
  else if((radiationSupport&&contrastSupport&&weakWind)||(onshore&&radiationSupport&&contrastSupport)){level='Mittel';description='Mehrere Anzeichen für Seewind; die lokale Windzunahme bleibt ungewiss.'}
  else if(solar===null&&temperatureDifference===null){level='Unbestimmt';description='Sonneneinstrahlung und Wassertemperatur fehlen; eine belastbare Thermikeinschätzung ist noch nicht möglich.'}
  if(solar===null)cautions.push('Zusätzliche Strahlungsdaten noch nicht verfügbar.');
  if(temperatureDifference===null)cautions.push('Wassertemperatur oder Lufttemperatur fehlt.');
 }
 cautions.push('Kein Zuschlag zu Wind, Böen, KiteScore oder Kitegrößenberechnung.');
 return{region:cape?'Kapstadt / Westkap':'Küstenregion',kind,level,description,factors,cautions,gradient,temperatureDifference,confidence:`${evidence}/${maxEvidence} Datensignale`,source:ctx.source||'forecast'};
}
window.KBThermics={VERSION:'0.70',PRO_ONLY:true,capetown,evaluate,sample};
})();
