Kitebuddies Nord Forecast Pro v0.65 Beta (Android) – Start- und Alarm-Bugfix

Basis: v0.64 Beta, gleiche packageId de.kitebuddies.forecast.prc und dauerhaftes Signaturzertifikat.

Änderungen gegenüber v0.64:
- Alarmgesteuerte Batch-Aktualisierung darf den Startbildschirm nicht erneut einblenden.
- Startup-Caches, Wetterdaten und Kartenwarteschritte erhalten Obergrenzen; Hintergrundabrufe laufen weiter.
- IndexedDB open/get/put mit Timeouts: kein unbegrenztes Hängen bei gesperrtem lokalen Cache.
- In-App-Forecast-Alarm läuft erst nach Freigabe der Oberfläche, nicht parallel zum Start.
- Gleicher Alarm wird nach App-Neustart 75 Minuten lang nicht erneut als In-App-Popup angezeigt (bei geänderten Regeln erneute Anzeige möglich).
- Unveränderte Push-/FCM-, Server-, Wetter-, Spot-, Favoriten-, Filter-, Lizenz- und Nutzereinstellungen.

Signatur: GitHub Actions build-v065.yml mit den bereits bestehenden Secrets KB_KEYSTORE_B64 und KB_KEYSTORE_PASSWORD.

Testpunkte:
1. App nach mehreren Stunden Inaktivität bei normalem Netz und bei langsamem Netz starten.
2. Prüfen, dass der Startbildschirm spätestens nach Ablauf begrenzter Datenabrufe schließt.
3. Alarm schließen, App unmittelbar komplett schließen und wieder starten; kein Duplikat.
4. Alarm bei geänderter Regel / neuer Prognose nach Ablauf des Cooldowns erneut prüfen.
5. Favoriten, Karte, Forecast und Push im laufenden Betrieb testen.
