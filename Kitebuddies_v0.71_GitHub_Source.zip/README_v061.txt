KITEBUDDIES NORD FORECAST PRO – v0.61 BETA
===========================================
Ausgangspunkt: v0.60 Beta vom 03.11.2026.

ÄNDERUNGEN (Android und Web/iOS identisch)
- Spot-Cockpit: Spotname zentriert, einheitliche Schriftgröße, fester
  Kopfbereich, maximal drei Zeilen; stabiles Layout beim Favoriten-Wischen.
- Spot-Region und Tags erscheinen über die kleine Info-Schaltfläche (i).
- Favorit (★/☆), Alarm (🔔/🔕) und Teilen (↗) rechts als platzsparende
  vertikale Aktionsleiste; jede Schaltfläche hat eine zugängliche Beschreibung.
- Alarmformular: durchgängige Feldhöhen (44px), symmetrische Abstände,
  einheitliche Beschriftung/Info-Knöpfe; Min/Max Grundwind,
  KiteScore/Confidence und Von/Bis jeweils nebeneinander.
- Bei sehr schmalem Display wechselt das Alarmformular auf eine Spalte.
- Diagramm-Detailfenster: per Tipp schließen, sonst automatisch nach
  20 Sekunden. Vorhandenes Verhalten bleibt erhalten.
- Alarmregeln, Favoriten, Push, Lizenzprüfung, Wettermodelle und
  persönliche Daten wurden nicht verändert.

WEB/iOS
- Inhalt des Verzeichnisses web-beta/ aus dem Web-ZIP in den bereits
  vorhandenen Web-Beta-Ordner auf den Server übertragen.
- Bestehende Server-/Lizenz- und Nutzerdaten NICHT überschreiben.
- web-version.json unbedingt zuletzt hochladen, um die neue Version
  erst nach vollständig übertragenen Dateien freizugeben.
- Web/iOS-Benachrichtigungen weiterhin nur bei geöffneter App.

ANDROID – GITHUB ACTIONS (direkter v0.61-Build)
- Der neue Workflow liegt als einzelne Datei build-v061.yml vor.
- In deinem GitHub-Repository unter .github/workflows/build-v061.yml
  hochladen (oder neu anlegen).
- Danach Kitebuddies_v0.61_GitHub_Source.zip unverändert ins
  Hauptverzeichnis deines Repositories hochladen.
- Der Push des Quell-ZIPs startet den Workflow automatisch. In GitHub
  Actions kann der Build auch manuell gestartet werden.
- Signing erfolgt ausschließlich über die bereits genutzten GitHub-
  Secrets KB_KEYSTORE_B64 und KB_KEYSTORE_PASSWORD. Die Schlüsseldatei
  und Passwörter gehören NICHT in das öffentliche Repository.
- Nach erfolgreichem Build steht ein Artifact mit der signierten
  Kitebuddies_Nord_Forecast_Pro_v0.61_Beta.apk und
  kitebuddies-update.json bereit.
- Das Server-Update-Manifest bitte erst nach Testinstallation auf dem
  Android-Gerät veröffentlichen.
- Die GitHub-Verbindung dieses ChatGPT-Laufs hat keine Schreibrechte
  (403). Deshalb ist kein Live-Build in deinem Repository gestartet.

PRÜFUNGEN
- Android/Web-JavaScript syntaktisch geprüft, eindeutige DOM-IDs.
- Patch gegen unverändertes v0.60-Archiv reproduziert den Android-Quellstand.
- Vollständiger Test der nativen APK und Live-Server/Push nach Build nötig.
