Kitebuddies Nord Forecast Pro v0.67 Beta – Overlay-Wiederherstellung und Kartenrand-Previews
Basis: vollständiger originaler v0.66-Beta-Quellstand (kein Neuaufbau). Paket de.kitebuddies.forecast.prc, versionCode 67.

1. Nach Android-Neustart oder Rückkehr aus Hintergrund: Der aktivierte Overlay-Zustand wird mit dem realen MapLibre-Pfeillayer abgeglichen. Fehlende Pfeile werden bei bereitstehendem Stil aus gespeicherten Rasterdaten wiederhergestellt. Gestaffelter, zeitlich begrenzter Retry; Event-Prüfung nach load/style.load/idle und App-Fokus. Keine Cache-Löschung, kein neuer API-Endpunkt, keine geänderte Windrichtung.
2. Spot-Infofenster an links/rechts und oben/unten gelegenen Kartenrändern: reale Abmessungen messen, Platz beider Seiten vergleichen und Reste pixelgenau in die Kartenansicht verschieben; auch nach Kartenverschiebung, Zoom und Drehung.
3. Maximal eine Vorschau auf Antippen; Einmalklick/Doppeltipp/3s-Longpress bleiben unverändert.
4. Anleitung, Versionstext und Update-Informationen auf v0.67 angepasst.

Tests: Android App bei aktiviertem Overlay hart beenden und starten; Netzverzögerung; App in Hintergrund und zurück; MapLibre-Stil langsam. Spot-Vorschau bei SPO links/rechts oben/unten; Pan/Zoom; Doppeltipp. Forecast, Windrichtung, Favoriten und Lizenz unverändert.
Hinweis: Dieser Quellcode ist noch keine signierte APK; Build/Signatur über bestehenden GitHub-Actions-Keystore prüfen.
