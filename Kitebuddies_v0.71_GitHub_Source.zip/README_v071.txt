Kitebuddies Nord Forecast Pro v0.71 Beta – Android
Basis: v0.70 Beta (einschließlich Thermik und regionaler Modelle)

- Spotvorschau mischt keine DWD-Windwerte mit Superforecast-Böen.
- DWD/ICON-Böen nur aus DWD-Spotmodell zur gleichen Stunde, wenn vergleichbar.
- Sonst bewusst "Böen –" plus Hinweis statt unlogischer Wert.
- Anzeige bei Dunkelheit: Nacht – kein Kitefenster.
- Außenring-Farben/Modellvertrauen verständlicher erklärt.
- Scores, Shore-Geometrie, Overlay, Filter, Firebase und Alarme unverändert.
- Anleitung und Update-Manifest aktualisiert.

Github: ZIP in Repository-Root, Workflow .github/workflows/build-v071.yml.
Hinweis: Nach dem Build signed APK und kitebuddies-update.json gemeinsam auf den Server laden.
