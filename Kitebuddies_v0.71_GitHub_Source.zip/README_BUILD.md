# Kitebuddies Nord Forecast Pro v0.58 Beta

Basis: v0.57 Beta.

Änderungen in v0.58:
- Beta-Lizenzprüfung gegen https://api.kitebuddies-nord.de/license/index.php
- Wiederverwendung derselben anonymen KB-Installations-ID wie bei Forecast-Alarmen
- Zentrale Freigabe/Sperre/Widerruf und globales Beta-Ende über das Admin-Center
- Serverseitig vorgegebene Offline-Toleranz (Standard 24 h) für bereits bestätigte Installationen
- Feste Sperransicht mit Installations-ID, Wiederholen und optionalem Vollversions-Link
- Keine Namen, E-Mail-Adressen oder Telefonnummern

Unverändert:
- Statusbar-Fix aus v0.57
- Forecast/Karte/Modelle
- Firebase Push und Alarmregeln
- Direkter Update-Download
- Paket-ID de.kitebuddies.forecast.prc und permanenter Signierschlüssel
