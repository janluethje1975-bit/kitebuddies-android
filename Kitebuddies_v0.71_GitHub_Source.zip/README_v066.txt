Kitebuddies Nord Forecast Pro v0.66 Beta – gezielter Windkarte-UI-Bugfix
Basis: v0.65 Beta. Paket: de.kitebuddies.forecast.prc. Signiert über bestehenden GitHub Actions Keystore.

1. Windpfeile beim Start: Die bei einem gespeicherten aktivierten Wind-Overlay nötige MapLibre-Stilbereitschaft wird jetzt abgewartet; Pfeil-Layer nach load/style.load/idle automatisch gezeichnet bzw. wiederhergestellt. Keine Änderung an Berechnung, Pfeilrichtung, Farbskala, API oder Cache-Format.
2. Spotkarte: Punkte bleiben immer sichtbar. Datenlabels nur nach explizitem Antippen eines Spots; höchstens ein Preview offen. Enthält Spotname, Wind, Windrichtung, ggf. Böen, KiteScore, Confidence, Shore. Freie Kartenfläche schließt Preview.
3. Spotauswahl: Einfach-Tipp und Doppeltipp für Forecast bleiben über die bestehenden Handler unverändert. Die ausgewählte Markierung bleibt bestehen.
4. Unverändert: Wettermodelle, Forecast, Windrange, Spotreihenfolge, eigene Spots, Alarme, Firebase, Profile, Authentifizierung und Navigation.

Tests:
- App mit eingeschaltetem Wind-Overlay vollständig schließen/neustarten: Pfeile erscheinen automatisch nach Daten-/Kartenbereitschaft.
- Fehmarn: Alle Punkte sichtbar ohne kollidierende Labels; Spot antippen -> genau ein Datenfähnchen; anderen antippen -> erstes zu, zweites auf.
- Doppeltipp öffnet Forecast, Langdruck 3s legt weiterhin eigenen Spot an.
- Kartenzoom, Pfeile, Richtung und Shore entsprechen v0.65.
- Verbindungsfehler: keine Windpfeile ohne Daten (kein Erfinden von Prognosen).
