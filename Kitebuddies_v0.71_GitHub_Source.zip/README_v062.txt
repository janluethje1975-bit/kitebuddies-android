KITEBUDDIES NORD FORECAST PRO v0.62 BETA
Basis: v0.61 Beta, ohne Daten-, API-, Wetter-, Filter-, Push-, Alarm- oder Lizenzlogik-Anpassungen.

Optische Optimierungen
- Spot-Cockpit wesentlich flacher; Spotname nur noch auf Spotkarte; Info-Button fuer Region und Tags.
- Kleine waagerechte Icons fuer Favorit, Alarm und Teilen; Favoriten-Wischen bleibt.
- Zeitraum-Anzeige nicht mehr doppelt; Filter und Ansichtsoptionen kompakter.
- Windfeld: linker vertikaler Windknots-Farbverlauf innerhalb der Karte.
- Windfeld-Serverstatus, Cache und Quelleninfos ueber Windfeld-(i)-Button.
- Wind-Zeitachse kompakt; Karte/Layer/Modelle unveraendert.
- Spots im Vergleich: knappe Bedienhinweise plus Info-Popup, weniger Abstaende.
- Anleitung mit v0.62-Kapitel aktualisiert.

Android: GitHub workflow build-v062.yml erzeugt nach Build/Signaturpruefung
Kitebuddies_Nord_Forecast_Pro_v0.62_Beta.apk und Update-Manifest.
Server-Manifest erst nach Installationstest veroeffentlichen.
