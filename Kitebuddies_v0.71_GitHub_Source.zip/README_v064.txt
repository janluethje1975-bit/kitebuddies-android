Kitebuddies Nord Forecast Pro v0.64 Beta (Android)
Basis: v0.63 mit unveränderter Paket-ID und permanenter Signatur.

1) Windlegende jetzt schmal und links unten in der Spotkarte.
2) Spots im Vergleich: ein-/ausklappen, zuletzt gewählte Ansicht lokal speichern, Favoriten-Filter und kompakte Spotkarten.
3) Bestes Kitefenster: Check ✓ grün, X rot, ? neutral (fehlende Daten) entsprechend den tatsächlich berechneten Kriterien.

Unverändert: API, Auth/Lizenz, Wind, Winddaten-Modelle, Karte, Alarme, Firebase Push, Profile, Favoritendaten, Serverupdate.
Installierbare signierte APK per GitHub Actions `.github/workflows/build-v064.yml` aus `Kitebuddies_v0.64_GitHub_Source.zip` erstellen.
Nach Geräteprüfung Version 64 und APK-Hash über `kitebuddies-update.json` veröffentlichen.
