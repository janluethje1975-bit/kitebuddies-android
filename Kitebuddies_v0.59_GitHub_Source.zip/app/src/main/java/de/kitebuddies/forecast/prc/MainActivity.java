package de.kitebuddies.forecast.prc;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.view.ViewGroup;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import com.google.firebase.messaging.FirebaseMessaging;
import org.json.JSONObject;

public class MainActivity extends Activity {
    private static final int REQ_NOTIFICATIONS=5201;
    private WebView webView;
    private String pendingId="",pendingSecret="",pendingVersion="";
    private String pendingSpotKey="";

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(8,20,28));
        webView=new WebView(this);
        webView.setBackgroundColor(Color.rgb(8,20,28));
        FrameLayout.LayoutParams webLp=new FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT);
        root.addView(webView,webLp);
        // Android 15+ draws app windows behind the system status bar.
        // Move the entire WebView below that inset instead of padding the WebView
        // itself. The root background remains behind the status icons, recreating
        // the clearly separated top system bar from the earlier stable layout.
        if(Build.VERSION.SDK_INT>=35){
            root.setOnApplyWindowInsetsListener((v,insets)->{
                int top=insets.getInsets(WindowInsets.Type.statusBars()).top;
                FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)webView.getLayoutParams();
                if(lp.topMargin!=top){
                    lp.topMargin=top;
                    webView.setLayoutParams(lp);
                }
                return insets;
            });
        }
        WebSettings s=webView.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setAllowFileAccessFromFileURLs(true); s.setAllowUniversalAccessFromFileURLs(true);
        webView.addJavascriptInterface(new PushBridge(),"AndroidPush");
        webView.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r){return openExternalIfNeeded(r.getUrl());}
            @Override public boolean shouldOverrideUrlLoading(WebView v,String url){return openExternalIfNeeded(Uri.parse(url));}
            @Override public void onPageFinished(WebView v,String url){super.onPageFinished(v,url);deliverPendingSpot();}
        });
        webView.setDownloadListener((url,userAgent,contentDisposition,mimeType,contentLength)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception ignored){}});
        setContentView(root); if(Build.VERSION.SDK_INT>=35)root.requestApplyInsets(); readIntent(getIntent()); webView.loadUrl("file:///android_asset/index.html");
    }
    private boolean openExternalIfNeeded(Uri u){
        String scheme=u.getScheme(); if("file".equalsIgnoreCase(scheme)||"about".equalsIgnoreCase(scheme))return false;
        if("http".equalsIgnoreCase(scheme)||"https".equalsIgnoreCase(scheme)){try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){} return true;} return false;
    }
    @Override protected void onNewIntent(Intent i){super.onNewIntent(i);setIntent(i);readIntent(i);deliverPendingSpot();}
    private void readIntent(Intent i){if(i!=null){String k=i.getStringExtra("kb_spot_key");if(k!=null&&!k.isEmpty())pendingSpotKey=k;}}
    private void deliverPendingSpot(){if(webView==null||pendingSpotKey.isEmpty())return;String k=pendingSpotKey;pendingSpotKey="";webView.evaluateJavascript("window.KBOpenAlarmSpot&&window.KBOpenAlarmSpot("+JSONObject.quote(k)+")",null);}
    private void jsResult(boolean ok,String msg){runOnUiThread(()->{if(webView!=null)webView.evaluateJavascript("window.KBPushNativeResult&&window.KBPushNativeResult("+(ok?"true":"false")+","+JSONObject.quote(msg)+")",null);});}
    private void connectNow(String id,String secret,String version){
        PushRegistrar.saveCredentials(this,id,secret,version);
        FirebaseMessaging.getInstance().getToken().addOnCompleteListener(task->{
            if(!task.isSuccessful()||task.getResult()==null){jsResult(false,"Firebase konnte keinen Push-Token erzeugen.");return;}
            PushRegistrar.sendToken(this,id,secret,version,task.getResult(),this::jsResult);
        });
    }
    @Override public void onRequestPermissionsResult(int req,String[] p,int[] g){super.onRequestPermissionsResult(req,p,g);if(req==REQ_NOTIFICATIONS){if(g.length>0&&g[0]==PackageManager.PERMISSION_GRANTED)connectNow(pendingId,pendingSecret,pendingVersion);else jsResult(false,"Benachrichtigungen wurden nicht erlaubt.");}}
    private final class PushBridge {
        @JavascriptInterface public void setTone(String tone){
            if(tone==null||!tone.matches("soft|classic|strong|silent"))tone="soft";
            getSharedPreferences("kb_alarm_audio_v059", MODE_PRIVATE).edit().putString("tone",tone).apply();
        }
        @JavascriptInterface public void connect(String id,String secret,String version){
            if(id==null||secret==null||id.length()<10||secret.length()<20){jsResult(false,"Ungültige anonyme Alarm-ID.");return;}
            pendingId=id;pendingSecret=secret;pendingVersion=(version==null||version.isEmpty())?"0.59 Beta":version;
            runOnUiThread(()->{
                if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ_NOTIFICATIONS); else connectNow(pendingId,pendingSecret,pendingVersion);
            });
        }
    }
}
